﻿namespace Demo.App.Models
{
    public class Permission
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
    }
}
