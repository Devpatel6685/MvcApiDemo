﻿using System.ComponentModel.DataAnnotations;

namespace Demo.App.Models
{
    public class ForgotPassword
    {
        [Required(ErrorMessage = "Email is required")]
        [RegularExpression("^[a-zA-Z0-9_\\.-]+@([a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$", ErrorMessage = "Please provide a valid email")]
        public string Email { get; set; }
    }
}
