﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Demo.App.Models
{
    public class Role
    {
        public Guid Id { get; set; }

        [Required(ErrorMessage = "Name is required")]
        [StringLength(50, ErrorMessage = "Name can have at most 50 characters")]
        public string Name { get; set; }
        public RolePermissions? RolePermissions { get; set; }
        public List<Permission> Permissions { get; set; }
    }
}
