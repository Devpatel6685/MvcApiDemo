﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Demo.App.Models
{
    public class Customer
    {
        public Guid Id { get; set; }

        [Required(ErrorMessage = "Name is required")]
        [StringLength(100, ErrorMessage = "Name can have at most 100 characters")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Address is required")]
        [StringLength(200, ErrorMessage = "Address can have at most 200 characters")]
        public string Address { get; set; }

        [Required(ErrorMessage = "City is required")]
        [StringLength(50, ErrorMessage = "City can have at most 50 characters")]
        public string City { get; set; }

        [Required(ErrorMessage = "ZIP Code is required")]
        [RegularExpression(@"^\d{6}$", ErrorMessage = "ZIP Code must be a 6-digit number")]
        public string ZipCode { get; set; }


        [Required(ErrorMessage = "Country is required")]
        [StringLength(50, ErrorMessage = "Country can have at most 50 characters")]
        public string Country { get; set; }

        [Required(ErrorMessage = "Mobile number is required")]
        [RegularExpression(@"^\d{10}$", ErrorMessage = "Mobile number must be a 10-digit number")]
        public string Mobile { get; set; }
    }
}
