﻿namespace Demo.App.Models
{
    public class RolePagePermission
    {
        public Guid Id { get; set; }
        public Guid PermissionId { get; set; }

        public Guid RoleId { get; set; }

        public Guid PageId { get; set; }
        public virtual ICollection<Role>? Roles { get; set; }

        public virtual ICollection<Page>? Pages { get; set; }

        public virtual ICollection<Permission>? Permissions { get; set; }

    }
}
