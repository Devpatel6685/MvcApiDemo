﻿using System.ComponentModel.DataAnnotations;


public class AtLeastOneSelected : ValidationAttribute
{
    protected override ValidationResult IsValid(object value, ValidationContext validationContext)
    {
        var selectedItems = value as List<string>;

        if (selectedItems == null || !selectedItems.Any())
        {
            return new ValidationResult(ErrorMessage);
        }

        return ValidationResult.Success;
    }
}
