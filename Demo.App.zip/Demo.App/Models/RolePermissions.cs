﻿using Demo.App.Models;

namespace Demo.App.Models
{
    public class RolePermissions
    {
        public Role Role { get; set; }
        public List<Permission> AllPermissions { get; set; }
        public List<Page> AllPages { get; set; }
        public List<RolePagePermission> RolePagePermissions { get; set; }
    }
}