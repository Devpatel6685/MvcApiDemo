﻿using System.ComponentModel.DataAnnotations;

namespace Demo.App.Models
{
    public class ResetPassword
    {
        [Required(ErrorMessage = "Password is required")]
        [RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\da-zA-Z]).{8,}$", ErrorMessage = "Password must contain atleast 1 lowercase, 1 uppercase, 1 digit, 1 special character and must be of 8 characters")]
        public string Password { get; set; }

        public string Token { get; set; }

        [Compare("Password", ErrorMessage = "Passwords do not match")]
        [RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\da-zA-Z]).{8,}$", ErrorMessage = "Password must contain atleast 1 lowercase,1 uppercase, 1 digit,1 special character and must be of 8 characters")]
        public string ConfirmPassword { get; set; }
    }
}
