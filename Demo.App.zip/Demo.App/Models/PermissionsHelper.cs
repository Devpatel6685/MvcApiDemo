﻿namespace Demo.App.Models
{
    public static class PermissionsHelper
    {
        public static bool HasPermission(Dictionary<string, List<string>> permissions, string key, string permission)
        {
            if (permissions.ContainsKey(key))
            {
                return permissions[key].Contains(permission) || permissions[key].Contains("All");
            }
            return false;
        }
    }
}
