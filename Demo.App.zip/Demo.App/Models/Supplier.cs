﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace Demo.App.Models
{
    public class Supplier
    {
        public Guid Id { get; set; }

        [Required(ErrorMessage = "Name is required")]
        [StringLength(100, ErrorMessage = "Name can have at most 100 characters")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Address is required")]
        [StringLength(200, ErrorMessage = "Address can have at most 200 characters")]
        public string Address { get; set; }

        [Required(ErrorMessage = "Item Price is required")]
        [Column(TypeName = "decimal(10,2)")]
        [Range(0.01, 999999.99, ErrorMessage = "Item Price must be between 0.01 and 999999.99")]
        public decimal ItemPrice { get; set; }

        [Required(ErrorMessage = "City is required")]
        [ForeignKey("City")]
        public Guid CityId { get; set; }

        [Required(ErrorMessage = "ZIP Code is required")]
        [RegularExpression(@"^\d{6}$", ErrorMessage = "ZIP Code must be a 6-digit number")]
        public string ZipCode { get; set; }

        [Required(ErrorMessage = "Country is required")]
        [StringLength(50, ErrorMessage = "Country can have at most 50 characters")]
        public string Country { get; set; }

        [Required(ErrorMessage = "Mobile number is required")]
        [RegularExpression(@"^\d{10}$", ErrorMessage = "Mobile number must be a 10-digit number")]
        public string Mobile { get; set; }

        public virtual City? City { get; set; }

        public virtual ICollection<SupplierItem>? SupplierItems { get; set; }

        [AtLeastOneSelected(ErrorMessage = "Please select at least one item")]
        public List<string>? SelectedSupplierItems { get; set; }

        public List<SelectListItem>? SupplierItem { get; set; }
        public List<SelectListItem>? Cities { get; set; }


    }
}
