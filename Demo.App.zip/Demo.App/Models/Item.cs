﻿namespace Demo.App.Models
{
    public class Item
    {
        public Guid Id { get; set; }
        public string ItemName { get; set; }
        public string Description { get; set; }
    }
}
