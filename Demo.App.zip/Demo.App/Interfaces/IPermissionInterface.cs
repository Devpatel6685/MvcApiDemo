﻿using System;
using System.Threading.Tasks;
using RestSharp;
using Demo.App.Models;

namespace Demo.App.Interfaces
{
    public interface IPermissionInterface
    {
        Task<RestResponse> GetAllPermissionsAsync(int pageNumber = 1, int pageSize = 10);
        Task<RestResponse> GetPermissionByIdAsync(Guid id);
        Task<RestResponse> AddPermission(Permission permission);
        Task<RestResponse> UpdatePermission(Permission permission);
        Task<RestResponse> DeletePermission(Guid id);
    }
}
