﻿using RestSharp;
using Demo.App.Models;

namespace Demo.App.Interfaces
{
    public interface IPageInterface
    {
        Task<RestResponse> GetAllPagesAsync();

        Task<RestResponse> GetPageByIdAsync(Guid id);

        Task<RestResponse> AddPage(Page page);

        Task<RestResponse> UpdatePage(Page page);

        Task<RestResponse> DeletePage(Guid id);
    }
}
