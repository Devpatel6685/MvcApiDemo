﻿using System;
using System.Threading.Tasks;
using RestSharp;
using Demo.App.Models;

namespace Demo.App.Interfaces
{
    public interface ICustomerInterface
    {
        Task<RestResponse> GetAllCustomersAsync();

        Task<RestResponse> GetCustomerByIdAsync(Guid id);

        Task<RestResponse> AddCustomer(Customer customer);

        Task<RestResponse> UpdateCustomer(Customer customer);

        Task<RestResponse> DeleteCustomer(Guid id);
    }
}
