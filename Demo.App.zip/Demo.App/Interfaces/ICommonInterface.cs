﻿using RestSharp;

namespace Demo.App.Interfaces
{
    public interface ICommonInterface<T> where T : class
    {
        Task<RestResponse> GetAll(string subURL);

        Task<RestResponse> GetById(Guid Id, string subURL);

        Task<RestResponse> Add(T model, string subURL);

        Task<RestResponse> Update(T model, string subURL);

        Task<RestResponse> Delete(Guid Id, string subURL);
    }
}
