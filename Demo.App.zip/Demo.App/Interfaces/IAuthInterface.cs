﻿using RestSharp;
using Demo.App.Models;
namespace Demo.App.Interfaces
{
    public interface IAuthInterface
    {
        Task<RestResponse> Login(Login model);  
    }
}
