﻿using RestSharp;
using Demo.App.Models;

namespace Demo.App.Interfaces
{
    public interface IUserInterface
    {
        Task<RestResponse> GetAllUsersAsync();

        Task<RestResponse> GetUserByIdAsync(Guid id);

        Task<RestResponse> AddUser(User user);

        Task<RestResponse> UpdateUser(User user);

        Task<RestResponse> DeleteUser(Guid id);
    }
}
