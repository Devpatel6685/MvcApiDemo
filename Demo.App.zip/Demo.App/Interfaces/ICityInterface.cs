﻿using System;
using System.Threading.Tasks;
using RestSharp;
using Demo.App.Models;

namespace Demo.App.Interfaces
{
    public interface ICityInterface
    {
        Task<RestResponse> GetAllCitiesAsync(int pageNumber = 1, int pageSize = 10);
        Task<RestResponse> GetCityByIdAsync(Guid id);
        Task<RestResponse> AddCity(City city);
        Task<RestResponse> UpdateCity(City city);
        Task<RestResponse> DeleteCity(Guid id);
    }
}
