﻿using System;
using System.Threading.Tasks;
using RestSharp;
using Demo.App.Models;

namespace Demo.App.Interfaces
{
    public interface IRolePagePermissionInterface
    {
        Task<RestResponse> GetAllRolePagePermissionsAsync(int pageNumber = 1, int pageSize = 10);
        Task<RestResponse> GetRolePagePermissionByIdAsync(Guid id);
        Task<RestResponse> AddRolePagePermission(RolePagePermission rolePagePermission);
        Task<RestResponse> UpdateRolePagePermission(RolePagePermission rolePagePermission);
        Task<RestResponse> DeleteRolePagePermission(Guid id);
    }
}
