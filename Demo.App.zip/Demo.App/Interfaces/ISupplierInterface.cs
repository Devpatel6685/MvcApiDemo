﻿using RestSharp;
using Demo.App.Models;

namespace Demo.App.Interfaces
{
    public interface ISupplierInterface
    {
        Task<RestResponse> GetAllSuppliersAsync();

        Task<RestResponse> GetSupplierByIdAsync(Guid id);

        Task<RestResponse> AddSupplier(Supplier supplier);

        Task<RestResponse> UpdateSupplier(Supplier supplier);

        Task<RestResponse> DeleteSupplier(Guid id);
    }
}
