﻿using RestSharp;
using Demo.App.Models;

namespace Demo.App.Interfaces
{
    public interface IRoleInterface
    {
        Task<RestResponse> GetAllRolesAsync();

        Task<RestResponse> GetRoleByIdAsync(Guid id);

        Task<RestResponse> AddRole(Role role);

        Task<RestResponse> UpdateRole(Role role);

        Task<RestResponse> DeleteRole(Guid id);
    }
}
