﻿using System;
using System.Threading.Tasks;
using RestSharp;
using Demo.App.Models;

namespace Demo.App.Interfaces
{
    public interface IItemInterface
    {
        Task<RestResponse> GetAllItemsAsync(int pageNumber = 1, int pageSize = 10);
        Task<RestResponse> GetItemByIdAsync(Guid id);
        Task<RestResponse> AddItem(Item item);
        Task<RestResponse> UpdateItem(Item item);
        Task<RestResponse> DeleteItem(Guid id);
    }
}
