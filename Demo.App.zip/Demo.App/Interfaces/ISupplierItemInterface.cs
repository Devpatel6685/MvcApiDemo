﻿using System;
using System.Threading.Tasks;
using RestSharp;
using Demo.App.Models;

namespace Demo.App.Interfaces
{
    public interface ISupplierItemInterface
    {
        Task<RestResponse> GetSupplierItemByIdAsync(Guid id);
        Task<RestResponse> AddSupplierItem(SupplierItem supplierItem);

        Task<RestResponse> GetItemIdsBySupplierId(Guid supplierId);
        Task<RestResponse> UpdateSupplierItem(SupplierItem supplierItem);
        Task<RestResponse> DeleteSupplierItem(Guid id);
    }
}
