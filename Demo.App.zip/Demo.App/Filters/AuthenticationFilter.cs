﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;

public class AuthenticationFilter : Attribute, IAuthorizationFilter
{
    public void OnAuthorization(AuthorizationFilterContext context)
    {
        var token = context.HttpContext.Session.GetString("Token");

        if (string.IsNullOrEmpty(token))
        {
            context.Result = new RedirectToActionResult("Login", "Auth", null);
        }
        else
        {
            try
            {
                var tokenHandler = new JwtSecurityTokenHandler();
                var jwtToken = tokenHandler.ReadJwtToken(token);

                var expiration = jwtToken.ValidTo;

                if (expiration <= DateTime.UtcNow)
                {
                    context.Result = new RedirectToActionResult("Login", "Auth", null);
                }
            }
            catch (SecurityTokenException)
            {
                context.Result = new RedirectToActionResult("Login", "Auth", null);
            }
        }
    }

}