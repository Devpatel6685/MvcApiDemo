﻿using Demo.App.Interfaces;
using RestSharp;

namespace Demo.App.Services
{
    public class CommonService<T> : ICommonInterface<T> where T : class
    {
        private readonly RestClient restClient;
        private readonly string baseurl;
        private readonly IConfiguration configuration;

        public CommonService(IConfiguration configuration)
        {
            this.configuration = configuration;
            baseurl = this.configuration.GetValue<string>("ApiUrl");
            restClient = new RestClient(baseurl);
        }

        public async Task<RestResponse> GetAll(string subURL)
        {
            var _RestRequest = new RestRequest(subURL, Method.Get)
            { RequestFormat = DataFormat.Json };

            var response = await restClient.ExecuteAsync(_RestRequest);
            return response;
        }

        public async Task<RestResponse> GetById(Guid Id, string subURL)
        {
            var _RestRequest = new RestRequest(subURL + Id, Method.Get)
            { RequestFormat = DataFormat.Json };

            var response = await restClient.ExecuteAsync(_RestRequest);
            return response;
        }

        public async Task<RestResponse> Add(T model, string subURL)
        {
            var _RestRequest = new RestRequest(subURL, Method.Post);
            _RestRequest.AddJsonBody(model);
            RestResponse _RestResponse = await restClient.ExecuteAsync(_RestRequest);
            return _RestResponse;
        }

        public async Task<RestResponse> Update(T model, string subURL)
        {
            var _RestRequest = new RestRequest(subURL, Method.Put);
            _RestRequest.AddJsonBody(model);
            RestResponse _RestResponse = await restClient.ExecuteAsync(_RestRequest);
            return _RestResponse;
        }

        public async Task<RestResponse> Delete(Guid Id, string subURL)
        {
            var _RestRequest = new RestRequest(subURL + Id, Method.Delete);
            RestResponse _RestResponse = await restClient.ExecuteAsync(_RestRequest);
            return _RestResponse;
        }
    }
}

