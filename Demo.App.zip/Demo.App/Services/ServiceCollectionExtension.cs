﻿using Demo.App.Interfaces;

namespace Demo.App.Services
{
    public static class ServiceCollectionExtension
    {
        public static IServiceCollection RegisterServices(this IServiceCollection services)
        {
            services.AddScoped(typeof(ICommonInterface<>), typeof(CommonService<>));
            services.AddScoped(typeof(IUserInterface), typeof(UserService));
            services.AddScoped(typeof(ICustomerInterface), typeof(CustomerService));
            services.AddScoped(typeof(ISupplierInterface), typeof(SupplierService));
            services.AddScoped(typeof(IPageInterface), typeof(PageService));
            services.AddScoped(typeof(IRoleInterface), typeof(RoleService));
            services.AddScoped(typeof(IItemInterface), typeof(ItemService));
            services.AddScoped(typeof(ICityInterface), typeof(CityService));
            services.AddScoped(typeof(ISupplierItemInterface), typeof(SupplierItemService));
            services.AddScoped(typeof(IRolePagePermissionInterface), typeof(RolePagePermissionService));
            services.AddScoped(typeof(IPermissionInterface), typeof(PermissionService));





            services.AddScoped<IAuthInterface, AuthService>();
            return services;
        }
    }
}
