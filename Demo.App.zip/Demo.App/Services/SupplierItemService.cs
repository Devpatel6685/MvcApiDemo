﻿using System;
using System.Threading.Tasks;
using RestSharp;
using Demo.App.Interfaces;
using Demo.App.Models;

namespace Demo.App.Services
{
    public class SupplierItemService : ISupplierItemInterface
    {
        private readonly ICommonInterface<SupplierItem> commonInterface;

        public SupplierItemService(ICommonInterface<SupplierItem> commonInterface)
        {
            this.commonInterface = commonInterface;
        }

        public async Task<RestResponse> GetSupplierItemByIdAsync(Guid id)
        {
            var restResponse = await commonInterface.GetById(id, $"api/SupplierItem/");
            return restResponse;
        }

        public async Task<RestResponse> AddSupplierItem(SupplierItem supplierItem)
        {
            var response = await commonInterface.Add(supplierItem, "api/SupplierItem/add");
            return response;
        }

        public async Task<RestResponse> GetItemIdsBySupplierId(Guid supplierId)
        {
            var restResponse = await commonInterface.GetById(supplierId,$"api/SupplierItem/getitemsbysupplier/");
            return restResponse;
        }
        public async Task<RestResponse> UpdateSupplierItem(SupplierItem supplierItem)
        {
            var response = await commonInterface.Update(supplierItem, $"api/SupplierItem/update/{supplierItem.Id}");
            return response;
        }

        public async Task<RestResponse> DeleteSupplierItem(Guid id)
        {
            var response = await commonInterface.Delete(id, $"api/SupplierItem/delete/");
            return response;
        }
    }
}
