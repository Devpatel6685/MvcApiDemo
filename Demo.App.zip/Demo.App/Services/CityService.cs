﻿using Demo.App.Interfaces;
using RestSharp;
using Demo.App.Models;

namespace Demo.App.Services
{
    public class CityService : ICityInterface
    {
        private readonly ICommonInterface<City> commonInterface;

        public CityService(ICommonInterface<City> commonInterface)
        {
            this.commonInterface = commonInterface;
        }

        public async Task<RestResponse> GetCityByIdAsync(Guid id)
        {
            var restResponse = await commonInterface.GetById(id, $"api/City/");
            return restResponse;
        }

            public async Task<RestResponse> GetAllCitiesAsync(int pageNumber = 1, int pageSize = 10)
            {
                string apiUrl = $"api/City/all?pageNumber={pageNumber}&pageSize={pageSize}";
                return await commonInterface.GetAll(apiUrl);
            }

        public async Task<RestResponse> AddCity(City city)
        {
            var response = await commonInterface.Add(city, "api/City/add");
            return response;
        }

        public async Task<RestResponse> UpdateCity(City city)
        {
            var response = await commonInterface.Update(city, $"api/City/update/{city.Id}");
            return response;
        }

        public async Task<RestResponse> DeleteCity(Guid id)
        {
            var response = await commonInterface.Delete(id, $"api/City/delete/");
            return response;
        }
    }
}
