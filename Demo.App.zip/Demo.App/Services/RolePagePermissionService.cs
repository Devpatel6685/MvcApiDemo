﻿using Demo.App.Interfaces;
using RestSharp;
using Demo.App.Models;

namespace Demo.App.Services
{
    public class RolePagePermissionService : IRolePagePermissionInterface
    {
        private readonly ICommonInterface<RolePagePermission> commonInterface;

        public RolePagePermissionService(ICommonInterface<RolePagePermission> commonInterface)
        {
            this.commonInterface = commonInterface;
        }

        public async Task<RestResponse> GetRolePagePermissionByIdAsync(Guid id)
        {
            var restResponse = await commonInterface.GetById(id, $"api/RolePagePermission/");
            return restResponse;
        }

        public async Task<RestResponse> GetAllRolePagePermissionsAsync(int pageNumber = 1, int pageSize = 10)
        {
            string apiUrl = $"api/RolePagePermission/all?pageNumber={pageNumber}&pageSize={pageSize}";
            return await commonInterface.GetAll(apiUrl);
        }

        public async Task<RestResponse> AddRolePagePermission(RolePagePermission rolePagePermission)
        {
            var response = await commonInterface.Add(rolePagePermission, "api/RolePagePermission/add");
            return response;
        }

        public async Task<RestResponse> UpdateRolePagePermission(RolePagePermission rolePagePermission)
        {
            var response = await commonInterface.Update(rolePagePermission, $"api/RolePagePermission/update/{rolePagePermission.Id}");
            return response;
        }

        public async Task<RestResponse> DeleteRolePagePermission(Guid id)
        {
            var response = await commonInterface.Delete(id, $"api/RolePagePermission/delete/");
            return response;
        }
    }
}
