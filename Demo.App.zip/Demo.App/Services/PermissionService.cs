﻿using Demo.App.Interfaces;
using RestSharp;
using Demo.App.Models;
using System;
using System.Threading.Tasks;

namespace Demo.App.Services
{
    public class PermissionService : IPermissionInterface
    {
        private readonly ICommonInterface<Permission> commonInterface;

        public PermissionService(ICommonInterface<Permission> commonInterface)
        {
            this.commonInterface = commonInterface;
        }

        public async Task<RestResponse> GetPermissionByIdAsync(Guid id)
        {
            var restResponse = await commonInterface.GetById(id, $"api/Permission/");
            return restResponse;
        }

        public async Task<RestResponse> GetAllPermissionsAsync(int pageNumber = 1, int pageSize = 10)
        {
            string apiUrl = $"api/Permission/all?pageNumber={pageNumber}&pageSize={pageSize}";
            return await commonInterface.GetAll(apiUrl);
        }

        public async Task<RestResponse> AddPermission(Permission permission)
        {
            var response = await commonInterface.Add(permission, "api/Permission/add");
            return response;
        }

        public async Task<RestResponse> UpdatePermission(Permission permission)
        {
            var response = await commonInterface.Update(permission, $"api/Permission/update/{permission.Id}");
            return response;
        }

        public async Task<RestResponse> DeletePermission(Guid id)
        {
            var response = await commonInterface.Delete(id, $"api/Permission/delete/");
            return response;
        }
    }
}
