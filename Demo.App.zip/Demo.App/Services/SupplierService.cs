﻿using RestSharp;
using Demo.App.Interfaces;
using Demo.App.Models;

namespace Demo.App.Services
{
    public class SupplierService : ISupplierInterface
    {
        private readonly ICommonInterface<Supplier> commonInterface;

        public SupplierService(ICommonInterface<Supplier> commonInterface)
        {
            this.commonInterface = commonInterface;
        }

        public async Task<RestResponse> GetSupplierByIdAsync(Guid id)
        {
            var restResponse = await commonInterface.GetById(id, $"api/Supplier/");
            return restResponse;
        }
        public async Task<RestResponse> GetAllSuppliersAsync()
        {
            string apiUrl = $"api/Supplier/all";
            return await commonInterface.GetAll(apiUrl);
        }

        public async Task<RestResponse> AddSupplier(Supplier supplier)
        {
            var response = await commonInterface.Add(supplier, "api/Supplier/add");
            return response;
        }

        public async Task<RestResponse> UpdateSupplier(Supplier supplier)
        {
            var response = await commonInterface.Update(supplier, $"api/Supplier/update/{supplier.Id}");
            return response;
        }

        public async Task<RestResponse> DeleteSupplier(Guid id)
        {
            var response = await commonInterface.Delete(id, $"api/Supplier/delete/");
            return response;
        }
    }
}
