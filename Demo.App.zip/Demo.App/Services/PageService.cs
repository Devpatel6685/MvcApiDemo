﻿using RestSharp;
using Demo.App.Models;
using Demo.App.Interfaces;

namespace Demo.App.Services
{
    public class PageService : IPageInterface
    {
        private readonly ICommonInterface<Page> _commonInterface;

        public PageService(ICommonInterface<Page> commonInterface)
        {
            _commonInterface = commonInterface;
        }

        public async Task<RestResponse> GetPageByIdAsync(Guid id)
        {
            var response = await _commonInterface.GetById(id, $"api/Page/");
            return response;
        }

        public async Task<RestResponse> GetAllPagesAsync()
        {
            string apiUrl = $"api/Page/all";
            return await _commonInterface.GetAll(apiUrl);
        }

        public async Task<RestResponse> AddPage(Page page)
        {
            var response = await _commonInterface.Add(page, "api/Page/add");
            return response;
        }

        public async Task<RestResponse> UpdatePage(Page page)
        {
            var response = await _commonInterface.Update(page, $"api/Page/update/{page.Id}");
            return response;
        }

        public async Task<RestResponse> DeletePage(Guid id)
        {
            var response = await _commonInterface.Delete(id, $"api/Page/delete/");
            return response;
        }
    }
}
