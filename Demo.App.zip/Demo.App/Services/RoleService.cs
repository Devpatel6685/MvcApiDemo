﻿using RestSharp;
using Demo.App.Interfaces;
using Demo.App.Models;

namespace Demo.App.Services
{
    public class RoleService : IRoleInterface
    {
        private readonly ICommonInterface<Role> commonInterface;

        public RoleService(ICommonInterface<Role> commonInterface)
        {
            this.commonInterface = commonInterface;
        }

        public async Task<RestResponse> GetRoleByIdAsync(Guid id)
        {
            var restResponse = await commonInterface.GetById(id, $"api/Role/");
            return restResponse;
        }

        public async Task<RestResponse> GetAllRolesAsync()
        {
            string apiUrl = $"api/Role/all";
            return await commonInterface.GetAll(apiUrl);
        }

        public async Task<RestResponse> AddRole(Role role)
        {
            var response = await commonInterface.Add(role, "api/Role/add");
            return response;
        }

        public async Task<RestResponse> UpdateRole(Role role)
        {
            var response = await commonInterface.Update(role, $"api/Role/update/{role.Id}");
            return response;
        }

        public async Task<RestResponse> DeleteRole(Guid id)
        {
            var response = await commonInterface.Delete(id, $"api/Role/delete/");
            return response;
        }
    }
}
