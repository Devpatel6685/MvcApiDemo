﻿using Demo.App.Interfaces;
using Demo.App.Models;
using RestSharp;

namespace Demo.App.Services
{
    public class AuthService : IAuthInterface
    {
        private readonly ICommonInterface<Login> commonInterface;

        public AuthService(ICommonInterface<Login> commonInterface)
        {
            this.commonInterface = commonInterface;
        }

        public async Task<RestResponse> Login(Login model)
        {
            var url = $"api/Auth/Login";
            var response = await commonInterface.Add(model, url);
            return response;
        }  
    }
}
