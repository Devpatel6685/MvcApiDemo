﻿using Demo.App.Interfaces;
using Demo.App.Models;
using RestSharp;

namespace Demo.App.Services
{
    public class UserService : IUserInterface
    {
        private readonly ICommonInterface<User> commonInterface;
        public UserService(ICommonInterface<User> commonInterface)
        {
            this.commonInterface = commonInterface;
        }
        public async Task<RestResponse> GetUserByIdAsync(Guid id)
        {
            var RestResponse = await commonInterface.GetById(id, $"api/User/");
            return RestResponse;
        }

        public async Task<RestResponse> GetAllUsersAsync()
        {
            string apiUrl = $"api/User/all";
            return await commonInterface.GetAll(apiUrl);
        }

        public async Task<RestResponse> AddUser(User user)
        {
            var response = await commonInterface.Add(user, "api/User/add");
            return response;
        }

        public async Task<RestResponse> UpdateUser(User user)
        {
            var response = await commonInterface.Update(user, $"api/User/update/{user.Id}");
            return response;
        }

        public async Task<RestResponse> DeleteUser(Guid id)
        {
            var response = await commonInterface.Delete(id, $"api/User/delete/");
            return response;
        }
    }
}
