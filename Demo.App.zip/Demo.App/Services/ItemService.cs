﻿using Demo.App.Interfaces;
using RestSharp;
using Demo.App.Models;

namespace Demo.App.Services
{
    public class ItemService : IItemInterface
    {
        private readonly ICommonInterface<Item> commonInterface;

        public ItemService(ICommonInterface<Item> commonInterface)
        {
            this.commonInterface = commonInterface;
        }

        public async Task<RestResponse> GetItemByIdAsync(Guid id)
        {
            var restResponse = await commonInterface.GetById(id, $"api/Item/");
            return restResponse;
        }

        public async Task<RestResponse> GetAllItemsAsync(int pageNumber = 1, int pageSize = 10)
        {
            string apiUrl = $"api/Item/all?pageNumber={pageNumber}&pageSize={pageSize}";
            return await commonInterface.GetAll(apiUrl);
        }

        public async Task<RestResponse> AddItem(Item item)
        {
            var response = await commonInterface.Add(item, "api/Item/add");
            return response;
        }

        public async Task<RestResponse> UpdateItem(Item item)
        {
            var response = await commonInterface.Update(item, $"api/Item/update/{item.Id}");
            return response;
        }

        public async Task<RestResponse> DeleteItem(Guid id)
        {
            var response = await commonInterface.Delete(id, $"api/Item/delete/");
            return response;
        }
    }
}
