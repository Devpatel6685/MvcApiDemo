﻿using RestSharp;
using Demo.App.Interfaces;
using Demo.App.Models;

namespace Demo.App.Services
{
    public class CustomerService : ICustomerInterface
    {
        private readonly ICommonInterface<Customer> commonInterface;

        public CustomerService(ICommonInterface<Customer> commonInterface)
        {
            this.commonInterface = commonInterface;
        }

        public async Task<RestResponse> GetCustomerByIdAsync(Guid id)
        {
            var restResponse = await commonInterface.GetById(id, $"api/Customer/");
            return restResponse;
        }

        public async Task<RestResponse> GetAllCustomersAsync()
        {
            string apiUrl = $"api/Customer/all";
            return await commonInterface.GetAll(apiUrl);
        }

        public async Task<RestResponse> AddCustomer(Customer customer)
        {
            var response = await commonInterface.Add(customer, "api/Customer/add");
            return response;
        }

        public async Task<RestResponse> UpdateCustomer(Customer customer)
        {
            var response = await commonInterface.Update(customer, $"api/Customer/update/{customer.Id}");
            return response;
        }

        public async Task<RestResponse> DeleteCustomer(Guid id)
        {
            var response = await commonInterface.Delete(id, $"api/Customer/delete/");
            return response;
        }
    }
}
