﻿using Microsoft.AspNetCore.Mvc;
using Demo.App.Models;
using Newtonsoft.Json;
using Demo.App.Interfaces;

namespace Demo.Api.Controllers
{
    public class SupplierItemController : Controller
    {
        private readonly ISupplierItemInterface supplierItemInterface;

        public SupplierItemController(ISupplierItemInterface supplierItemInterface)
        {
            this.supplierItemInterface = supplierItemInterface;
        }

        [HttpGet]
        public async Task<IActionResult> SupplierItemDetails(Guid id)
        {
            var response = await supplierItemInterface.GetSupplierItemByIdAsync(id);
            if (response.IsSuccessful)
            {
                var supplierItemDetail = JsonConvert.DeserializeObject<SupplierItem>(response.Content);
                return View(supplierItemDetail);
            }
            else
            {
                return NotFound();
            }
        }

        [HttpPost]
        public async Task<IActionResult> AddSupplierItem(SupplierItem supplierItem)
        {
            var response = await supplierItemInterface.AddSupplierItem(supplierItem);
            if (response.IsSuccessful)
            {
                return Ok(response.Content);
            }
            else
            {
                return BadRequest(response.ErrorMessage);
            }
        }

        [HttpPost]
        public async Task<IActionResult> UpdateSupplierItem(SupplierItem supplierItem)
        {
            var response = await supplierItemInterface.UpdateSupplierItem(supplierItem);
            if (response.IsSuccessful)
            {
                return Ok(response.Content);
            }
            else
            {
                return BadRequest(response.ErrorMessage);
            }
        }
        [HttpGet]
        public async Task<IActionResult> GetItemIdsBySupplierId(string supplierId)
        {
            if (Guid.TryParse(supplierId, out Guid parsedSupplierId))
            {
                var response = await supplierItemInterface.GetItemIdsBySupplierId(parsedSupplierId);
                if (response.IsSuccessful)
                {
                    var itemIds = JsonConvert.DeserializeObject<IEnumerable<Guid>>(response.Content);
                    return Ok(itemIds);
                }
                else
                {
                    return BadRequest(response.ErrorMessage);
                }
            }
            else
            {
                // Handle parsing failure
                return BadRequest("Invalid supplierId format");
            }
        }


        public async Task<IActionResult> DeleteSupplierItem(Guid id)
        {
            var response = await supplierItemInterface.DeleteSupplierItem(id);
            if (response.IsSuccessful)
            {
                return Ok(response.Content);
            }
            else
            {
                return BadRequest(response.ErrorMessage);
            }
        }
    }
}
