﻿using Microsoft.AspNetCore.Mvc;
using Demo.App.Interfaces;
using Demo.App.Models;
using Newtonsoft.Json;

namespace Demo.App.Controllers
{
    public class UserController : Controller
    {

        private readonly IUserInterface userInterface;

        public UserController(IUserInterface user)
        {
            this.userInterface = user;
        }

        [HttpGet]
        public async Task<IActionResult> UserDetails(Guid id)
        {
            var response = await userInterface.GetUserByIdAsync(id);
            if (response.IsSuccessful)
            {
                var userDetail = JsonConvert.DeserializeObject<User>(response.Content);
                return View(userDetail);
            }
            else
            {
                return NotFound();
            }
        }
        public ActionResult UserEdit()
        {
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> GetUserDetails(Guid id)
        {
            var response = await userInterface.GetUserByIdAsync(id);

            if (response.IsSuccessful)
            {
                var user = JsonConvert.DeserializeObject<User>(response.Content);
                return View("UserEdit", user);
            }
            else
            {
                return NotFound();
            }
        }


        [HttpGet]
        public PartialViewResult GetAddUserPartial()
        {
            return PartialView("_AddUserPartial");
        }
        [HttpGet]
        public async Task<IActionResult> UserListing()
        {
            var response = await userInterface.GetAllUsersAsync();
            if (response.IsSuccessful)
            {
                var users = JsonConvert.DeserializeObject<List<User>>(response.Content);
                ViewBag.PageSize  = new Dictionary<Int32, String> { { 0, "All" }, { 2, "2" }, { 4, "4" } };
                return View(users);
            }
            else
            {
                return BadRequest(response.ErrorMessage);
            }
        }

        [HttpPost]
        public async Task<IActionResult> AddUser(User user)
        {
            var response = await userInterface.AddUser(user);
            if (response.IsSuccessful)
            {
                return RedirectToAction("UserListing", "User");
            }
            else
            {
                return BadRequest(response.ErrorMessage);
            }
        }
        [HttpPost]
        public async Task<IActionResult> UpdateUser(User user)
        {
            var response = await userInterface.UpdateUser(user);
            if (response.IsSuccessful)
            {
                return RedirectToAction("UserListing", "User");
            }
            else
            {
                return BadRequest(response.ErrorMessage);
            }
        }
        public async Task<IActionResult> DeleteUser(Guid id)
        {
            var response = await userInterface.DeleteUser(id);
            if (response.IsSuccessful)
            {
                return Ok(response.Content);
            }
            else
            {
                return BadRequest(response.ErrorMessage);
            }
        }
    }
}
