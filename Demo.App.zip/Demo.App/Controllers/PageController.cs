﻿using Microsoft.AspNetCore.Mvc;
using Demo.App.Interfaces;
using Demo.App.Models;
using Newtonsoft.Json;

namespace Demo.App.Controllers
{
    public class PageController : Controller
    {
        private readonly IPageInterface _pageInterface;

        public PageController(IPageInterface pageInterface)
        {
            _pageInterface = pageInterface;
        }

        public ActionResult PageAddEdit()
        {
            return View();
        }
        [HttpGet]
        public async Task<IActionResult> GetPageDetails(Guid id)
        {
            var response = await _pageInterface.GetPageByIdAsync(id);

            if (response.IsSuccessful)
            {
                var Customer = JsonConvert.DeserializeObject<Page>(response.Content);
                return View("PageAddEdit", Customer);
            }
            else
            {
                return NotFound();
            }
        }
        [HttpGet]
        public async Task<IActionResult> PageListing()
        {
            var response = await _pageInterface.GetAllPagesAsync();
            if (response.IsSuccessful)
            {
                var Pages = JsonConvert.DeserializeObject<List<Page>>(response.Content);
                ViewBag.PageSize = new Dictionary<Int32, String> { { 0, "All" }, { 2, "2" }, { 4, "4" } };
                return View(Pages);
            }
            else
            {
                return BadRequest(response.ErrorMessage);
            }
        }

        public async Task<IActionResult> AddPage(Page page)
        {
            var response = await _pageInterface.AddPage(page);
            if (response.IsSuccessful)
            {
                return RedirectToAction("PageListing", "Page");
            }
            else
            {
                return BadRequest(response.ErrorMessage);
            }
        }

        public async Task<IActionResult> UpdatePage(Page page)
        {
            var response = await _pageInterface.UpdatePage(page);
            if (response.IsSuccessful)
            {
                return RedirectToAction("PageListing", "Page");
            }
            else
            {
                return BadRequest(response.ErrorMessage);
            }
        }

        public async Task<IActionResult> DeletePage(Guid id)
        {
            var response = await _pageInterface.DeletePage(id);
            if (response.IsSuccessful)
            {
                return Ok(response.Content);
            }
            else
            {
                return BadRequest(response.ErrorMessage);
            }
        }
    }
}
