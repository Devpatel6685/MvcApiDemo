﻿using Microsoft.AspNetCore.Mvc;
using Demo.App.Interfaces;
using Demo.App.Models;
using Newtonsoft.Json;

namespace Demo.App.Controllers
{
    public class CustomerController : Controller
    {
        private readonly ICustomerInterface customerInterface;

        public CustomerController(ICustomerInterface customerInterface)
        {
            this.customerInterface = customerInterface;
        }

        [HttpGet]
        public async Task<IActionResult> CustomerDetails(Guid id)
        {
            var response = await customerInterface.GetCustomerByIdAsync(id);
            if (response.IsSuccessful)
            {
                var customerDetail = JsonConvert.DeserializeObject<Customer>(response.Content);
                return View(customerDetail);
            }
            else
            {
                return NotFound();
            }
        }
        public ActionResult CustomerAddEdit()
        {
            return View();
        }
        [HttpGet]
        public async Task<IActionResult> GetCustomerDetails(Guid id)
        {
            var response = await customerInterface.GetCustomerByIdAsync(id);

            if (response.IsSuccessful)
            {
                var Customer = JsonConvert.DeserializeObject<Customer>(response.Content);
                return View("CustomerAddEdit", Customer);
            }
            else
            {
                return NotFound();
            }
        }
        [HttpGet]
        public async Task<IActionResult> CustomerListing()
        {
            var response = await customerInterface.GetAllCustomersAsync();
            if (response.IsSuccessful)
            {
                var Customers = JsonConvert.DeserializeObject<List<Customer>>(response.Content);
                ViewBag.PageSize = new Dictionary<Int32, String> { { 0, "All" }, { 2, "2" }, { 4, "4" } };
                return View(Customers);
            }
            else
            {
                return BadRequest(response.ErrorMessage);
            }
        }

        public async Task<IActionResult> AddCustomer(Customer customer)
        {
            var response = await customerInterface.AddCustomer(customer);
            if (response.IsSuccessful)
            {
                return RedirectToAction("CustomerListing", "Customer");
            }
            else
            {
                return BadRequest(response.ErrorMessage);
            }
        }

        public async Task<IActionResult> UpdateCustomer(Customer customer)
        {
            var response = await customerInterface.UpdateCustomer(customer);
            if (response.IsSuccessful)
            {
                return RedirectToAction("CustomerListing", "Customer");
            }
            else
            {
                return BadRequest(response.ErrorMessage);
            }
        }

        public async Task<IActionResult> DeleteCustomer(Guid id)
        {
            var response = await customerInterface.DeleteCustomer(id);
            if (response.IsSuccessful)
            {
                return Ok(response.Content);
            }
            else
            {
                return BadRequest(response.ErrorMessage);
            }
        }
    }
}
