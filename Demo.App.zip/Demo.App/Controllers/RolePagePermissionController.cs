﻿    using Microsoft.AspNetCore.Mvc;
using Demo.App.Interfaces;
using Demo.App.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Demo.App.Controllers
{
    public class RolePagePermissionController : Controller
    {
        private readonly IRolePagePermissionInterface rolePagePermissionInterface;

        public RolePagePermissionController(IRolePagePermissionInterface rolePagePermission)
        {
            this.rolePagePermissionInterface = rolePagePermission;
        }

        [HttpGet]
        public async Task<IActionResult> RolePagePermissionDetails(Guid id)
        {
            var response = await rolePagePermissionInterface.GetRolePagePermissionByIdAsync(id);
            if (response.IsSuccessful)
            {
                var rolePagePermissionDetail = JsonConvert.DeserializeObject<RolePagePermission>(response.Content);
                return View(rolePagePermissionDetail);
            }
            else
            {
                return NotFound();
            }
        }

        [HttpGet]
        public async Task<IActionResult> RolePagePermissionListing(int pageNumber = 1, int pageSize = 10)
        {
            var response = await rolePagePermissionInterface.GetAllRolePagePermissionsAsync(pageNumber, pageSize);
            if (response.IsSuccessful)
            {
                var rolePagePermissions = JsonConvert.DeserializeObject<List<RolePagePermission>>(response.Content);

                int totalCount = rolePagePermissions.Count();
                int pageCount = (int)Math.Ceiling((double)totalCount / pageSize);
                int startIdx = (pageNumber - 1) * pageSize;
                var pagedRolePagePermissions = rolePagePermissions.Skip(startIdx).Take(pageSize).ToList();

                ViewBag.PageNumber = pageNumber;
                ViewBag.PageCount = pageCount;
                ViewBag.PageSize = pageSize;

                return View(pagedRolePagePermissions);
            }
            else
            {
                return BadRequest(response.ErrorMessage);
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetAllRolePagePermissions()
        {
            var response = await rolePagePermissionInterface.GetAllRolePagePermissionsAsync();
            if (response.IsSuccessful)
            {
                var rolePagePermissions = JsonConvert.DeserializeObject<List<RolePagePermission>>(response.Content);
                return Json(rolePagePermissions); // Return the items as JSON
            }
            else
            {
                return BadRequest(response.ErrorMessage);
            }
        }

        public async Task<IActionResult> AddRolePagePermission(RolePagePermission rolePagePermission)
        {
            var response = await rolePagePermissionInterface.AddRolePagePermission(rolePagePermission);
            if (response.IsSuccessful)
            {
                return Ok(response.Content);
            }
            else
            {
                return BadRequest(response.ErrorMessage);
            }
        }

        public async Task<IActionResult> UpdateRolePagePermission(RolePagePermission rolePagePermission)
        {
            var response = await rolePagePermissionInterface.UpdateRolePagePermission(rolePagePermission);
            if (response.IsSuccessful)
            {
                return RedirectToAction("Dashboard", "Home");
            }
            else
            {
                return BadRequest(response.ErrorMessage);
            }
        }

        public async Task<IActionResult> DeleteRolePagePermission(Guid id)
        {
            var response = await rolePagePermissionInterface.DeleteRolePagePermission(id);
            if (response.IsSuccessful)
            {
                return Ok(response.Content);
            }
            else
            {
                return BadRequest(response.ErrorMessage);
            }
        }
    }
}
