﻿using Microsoft.AspNetCore.Mvc;
using Demo.App.Interfaces;
using Demo.App.Models;
using Newtonsoft.Json;


namespace Demo.App.Controllers
{
    public class RoleController : Controller
    {
        private readonly IRoleInterface roleInterface;
        private readonly IPageInterface pageInterface;
        private readonly IRolePagePermissionInterface rolePagePermission;
        private readonly IPermissionInterface permissionInterface;

        public RoleController(IRoleInterface roleInterface,IPageInterface pageInterface,IRolePagePermissionInterface rolePagePermissionInterface,IPermissionInterface permissionInterface)
        {
            
            this.roleInterface = roleInterface;
            this.pageInterface = pageInterface;
            this.permissionInterface = permissionInterface;
            this.rolePagePermission=rolePagePermissionInterface;
        }

        [HttpGet]
        public async Task<IActionResult> RoleDetails(Guid id)
        {
            var response = await roleInterface.GetRoleByIdAsync(id);
            if (response.IsSuccessful)
            {
                var roleDetail = JsonConvert.DeserializeObject<Role>(response.Content);
                return View(roleDetail);
            }
            else
            {
                return NotFound();
            }
        }
        public ActionResult RoleAddEdit()
        {
            return View();
        }
        [HttpGet]
        public async Task<IActionResult> EditRoleWithPermissions(Guid id)
        {   

            var roleResponse = await roleInterface.GetRoleByIdAsync(id);

            if (roleResponse.IsSuccessful)
            {
                var role = JsonConvert.DeserializeObject<Role>(roleResponse.Content);
                var permissionsModel = await permission(id);

                var model = new RolePermissions
                {
                    Role = role,
                    AllPages = permissionsModel.AllPages,
                    AllPermissions = permissionsModel.AllPermissions,
                    RolePagePermissions = permissionsModel.RolePagePermissions
                };

                return View("RolePermissions", model);
            }
            else
            {
                return NotFound();
            }
        }

        [HttpGet]
        public async Task<IActionResult> RoleListing()
        {
            var response = await roleInterface.GetAllRolesAsync();
            if (response.IsSuccessful)
            {
                var Roles = JsonConvert.DeserializeObject<List<Role>>(response.Content);
                ViewBag.PageSize = new Dictionary<Int32, String> { { 0, "All" }, { 2, "2" }, { 4, "4" } };
                return View(Roles);
            }
            else
            {
                return BadRequest(response.ErrorMessage);
            }
        }

        [HttpPost]
        public async Task<IActionResult> AddRole(Role role)
        {
            var response = await roleInterface.AddRole(role);
            if (response.IsSuccessful)
            {
                return RedirectToAction("RoleListing", "Role");
            }
            else
            {
                return BadRequest(response.ErrorMessage);
            }
        } 
        [HttpGet]
        public async Task<IActionResult> ManagePermissionsforView(Guid id)
        {
            Role role = new Role();
            var model = await permission(id);
            role.RolePermissions = model;
            return PartialView("_RolePermissionsPartial", role.RolePermissions);
        }
        public async Task<RolePermissions> permission(Guid id)
        {
            var roleResponse = await roleInterface.GetRoleByIdAsync(id);
            var rolePagePermissionsResponse = await rolePagePermission.GetRolePagePermissionByIdAsync(id);
            var allPagesResponse = await pageInterface.GetAllPagesAsync();
            var allPermissionsResponse = await permissionInterface.GetAllPermissionsAsync();


            if (!roleResponse.IsSuccessful || !allPermissionsResponse.IsSuccessful || !rolePagePermissionsResponse.IsSuccessful || !allPagesResponse.IsSuccessful)
            {
                return null;
            }

            var roleDetail = JsonConvert.DeserializeObject<Role>(roleResponse.Content);
            var allPermissions = JsonConvert.DeserializeObject<List<Permission>>(allPermissionsResponse.Content);
            var rolePagePermissions = JsonConvert.DeserializeObject<List<RolePagePermission>>(rolePagePermissionsResponse.Content);
            var allPages = JsonConvert.DeserializeObject<List<Page>>(allPagesResponse.Content);

            var model = new RolePermissions
            {
                Role = roleDetail,
                AllPermissions = allPermissions,
                AllPages = allPages,
                RolePagePermissions = rolePagePermissions
            };
            return model;
        }


        [HttpPost]
        public async Task<IActionResult> UpdateRolePagePermission(Guid roleId, List<string> selectedPermissions)
        {
            var allPagesResponse = await pageInterface.GetAllPagesAsync();

            if (!allPagesResponse.IsSuccessful)
            {
              
                return RedirectToAction("RoleListing", "Role");
            }

            var allPages = JsonConvert.DeserializeObject<List<Page>>(allPagesResponse.Content);

            var existingPermissionsResponse = await rolePagePermission.GetRolePagePermissionByIdAsync(roleId);

            if (existingPermissionsResponse.IsSuccessful)
            {
                var existingRolePagePermissions = JsonConvert.DeserializeObject<List<RolePagePermission>>(existingPermissionsResponse.Content);

                foreach (var page in allPages)
                {
                    // Delete existing records for role id 
                    await rolePagePermission.DeleteRolePagePermission(roleId);


                    foreach (var selectedPermission in selectedPermissions)
                    {
                        var permissionIds = selectedPermission.Split(',');
                        var pageId = Guid.Parse(permissionIds[0]);
                        var permissionId = Guid.Parse(permissionIds[1]);

                        await rolePagePermission.AddRolePagePermission(new RolePagePermission
                        {
                            RoleId = roleId,
                            PageId = pageId,
                            PermissionId = permissionId
                        });
                    }
                }
            }

            return RedirectToAction("RoleListing", "Role");
        }
        [HttpPost]
        public async Task<IActionResult> UpdateRoleWithPermissions(Role role, List<string> selectedPermissions)
        {
            var allPagesResponse = await pageInterface.GetAllPagesAsync();

            if (!allPagesResponse.IsSuccessful)
            {
                return RedirectToAction("RoleListing", "Role");
            }

            var allPages = JsonConvert.DeserializeObject<List<Page>>(allPagesResponse.Content);

            var response = await roleInterface.UpdateRole(role);

            if (!response.IsSuccessful)
            {
                return BadRequest(response.ErrorMessage);
            }

            var roleId = role.Id;

            var existingPermissionsResponse = await rolePagePermission.GetRolePagePermissionByIdAsync(roleId);

            if (existingPermissionsResponse.IsSuccessful)
            {
                var existingRolePagePermissions = JsonConvert.DeserializeObject<List<RolePagePermission>>(existingPermissionsResponse.Content);

                foreach (var page in allPages)
                {
                    await rolePagePermission.DeleteRolePagePermission(roleId);

                    foreach (var selectedPermission in selectedPermissions)
                    {
                        var permissionIds = selectedPermission.Split(',');
                        var pageId = Guid.Parse(permissionIds[0]);
                        var permissionId = Guid.Parse(permissionIds[1]);

                        await rolePagePermission.AddRolePagePermission(new RolePagePermission
                        {
                            RoleId = roleId,
                            PageId = pageId,
                            PermissionId = permissionId
                        });
                    }
                }
            }

            return RedirectToAction("RoleListing", "Role");
        }

        [HttpPost]
        public async Task<IActionResult> UpdateRole(Role role)
        {
            var response = await roleInterface.UpdateRole(role);
            if (response.IsSuccessful)
            {
                return RedirectToAction("RoleListing", "Role");
            }
            else
            {
                return BadRequest(response.ErrorMessage);
            }
        }

        public async Task<IActionResult> DeleteRole(Guid id)
        {
            var response = await roleInterface.DeleteRole(id);
            if (response.IsSuccessful)
            {
                return Ok(response.Content);
            }
            else
            {
                return BadRequest(response.ErrorMessage);
            }
        }
    }
}
