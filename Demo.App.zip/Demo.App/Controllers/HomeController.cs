﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using Demo.App.Models;

namespace Demo.App.Controllers
{
    [AuthenticationFilter]
    public class HomeController : Controller
    {
        public HomeController() { }

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult DashBoard()
        {
            return View();
        }
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new Error { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}