﻿using Microsoft.AspNetCore.Mvc;
using Demo.App.Interfaces;
using Demo.App.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Demo.App.Controllers
{
    public class ItemController : Controller
    {
        private readonly IItemInterface itemInterface;

        public ItemController(IItemInterface item)
        {
            this.itemInterface = item;
        }

        [HttpGet]
        public async Task<IActionResult> ItemDetails(Guid id)
        {
            var response = await itemInterface.GetItemByIdAsync(id);
            if (response.IsSuccessful)
            {
                var itemDetail = JsonConvert.DeserializeObject<Item>(response.Content);
                return View(itemDetail);
            }
            else
            {
                return NotFound();
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetAllItems()
        {
            var response = await itemInterface.GetAllItemsAsync();
            if (response.IsSuccessful)
            {
                var items = JsonConvert.DeserializeObject<List<Item>>(response.Content);
                return Json(items); 
            }
            else
            {
                return BadRequest(response.ErrorMessage);
            }
        }

        public async Task<IActionResult> AddItem(Item item)
        {
            var response = await itemInterface.AddItem(item);
            if (response.IsSuccessful)
            {
                return Ok(response.Content);
            }
            else
            {
                return BadRequest(response.ErrorMessage);
            }
        }

        public async Task<IActionResult> UpdateItem(Item item)
        {
            var response = await itemInterface.UpdateItem(item);
            if (response.IsSuccessful)
            {
                return RedirectToAction("Dashboard", "Home");
            }
            else
            {
                return BadRequest(response.ErrorMessage);
            }
        }

        public async Task<IActionResult> DeleteItem(Guid id)
        {
            var response = await itemInterface.DeleteItem(id);
            if (response.IsSuccessful)
            {
                return Ok(response.Content);
            }
            else
            {
                return BadRequest(response.ErrorMessage);
            }
        }
    }
}
