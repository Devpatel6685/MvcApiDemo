﻿using Microsoft.AspNetCore.Mvc;
using Demo.App.Interfaces;
using Demo.App.Models;
using Newtonsoft.Json;

namespace Demo.App.Controllers
{
    public class CityController : Controller
    {
        private readonly ICityInterface cityInterface;

        public CityController(ICityInterface city)
        {
            this.cityInterface = city;
        }

        [HttpGet]
        public async Task<IActionResult> CityDetails(Guid id)
        {
            var response = await cityInterface.GetCityByIdAsync(id);
            if (response.IsSuccessful)
            {
                var cityDetail = JsonConvert.DeserializeObject<City>(response.Content);
                return View(cityDetail);
            }
            else
            {
                return NotFound();
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetAllCities()
        {
            var response = await cityInterface.GetAllCitiesAsync();
            if (response.IsSuccessful)
            {
                var Cities = JsonConvert.DeserializeObject<List<City>>(response.Content);
                return Json(Cities); 
            }
            else
            {
                return BadRequest(response.ErrorMessage);
            }
        }
        public async Task<IActionResult> AddCity(City city)
        {
            var response = await cityInterface.AddCity(city);
            if (response.IsSuccessful)
            {
                return Ok(response.Content);
            }
            else
            {
                return BadRequest(response.ErrorMessage);
            }
        }

        public async Task<IActionResult> UpdateCity(City city)
        {
            var response = await cityInterface.UpdateCity(city);
            if (response.IsSuccessful)
            {
                return RedirectToAction("Dashboard", "Home");
            }
            else
            {
                return BadRequest(response.ErrorMessage);
            }
        }

        public async Task<IActionResult> DeleteCity(Guid id)
        {
            var response = await cityInterface.DeleteCity(id);
            if (response.IsSuccessful)
            {
                return Ok(response.Content);
            }
            else
            {
                return BadRequest(response.ErrorMessage);
            }
        }
    }
}
