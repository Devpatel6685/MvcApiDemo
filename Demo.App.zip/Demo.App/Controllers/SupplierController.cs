﻿using Microsoft.AspNetCore.Mvc;
using Demo.App.Models;
using Newtonsoft.Json;
using Demo.App.Interfaces;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Demo.Api.Controllers
{
    public class SupplierController : Controller
    {
        private readonly ISupplierInterface supplierInterface;
        private readonly ICityInterface cityInterface;
        private readonly IItemInterface itemInterface;


        public SupplierController(ISupplierInterface supplierInterface, ICityInterface cityInterface, IItemInterface itemInterface)
        {
            this.supplierInterface = supplierInterface;
            this.cityInterface = cityInterface;
            this.itemInterface = itemInterface;
        }
        public async Task<IActionResult> SupplierAddEdit()
        {
            var supplier = await PrepareSupplierViewModel();
            return View("SupplierAddEdit", supplier);
        }

        [HttpGet]
        public async Task<IActionResult> GetSupplierDetails(Guid id)
        {
            var supplier = await PrepareSupplierViewModelWithId(id);

            if (supplier == null)
            {
                return NotFound();
            }

            return View("SupplierAddEdit", supplier);
        }
        private async Task<Supplier> PrepareSupplierViewModelWithId(Guid id)
        {
            var response = await supplierInterface.GetSupplierByIdAsync(id);

            if (!response.IsSuccessful)
            {
                return null;
            }

            var supplier = JsonConvert.DeserializeObject<Supplier>(response.Content);
            var ItemResponse = await itemInterface.GetAllItemsAsync();
            if (ItemResponse.IsSuccessful)
            {
                var Items = JsonConvert.DeserializeObject<List<Item>>(ItemResponse.Content);
                supplier.SupplierItem = Items
                    .Select(p => new SelectListItem
                    {
                        Text = p.ItemName,
                        Value = p.Id.ToString(),
                        Selected = supplier.SupplierItems.Any(s => s.ItemId == p.Id)
                    })
                    .ToList();
            }

            var citiesResponse = await cityInterface.GetAllCitiesAsync();
            if (citiesResponse.IsSuccessful)
            {
                var cities = JsonConvert.DeserializeObject<List<City>>(citiesResponse.Content);
                supplier.Cities = cities
                    .Select(c => new SelectListItem
                    {
                        Text = c.Name,
                        Value = c.Id.ToString(),
                        Selected = c.Id == supplier.CityId
                    })
                    .ToList();
            }

            return supplier;
        }

        private async Task<Supplier> PrepareSupplierViewModel()
        {
            var supplier = new Supplier();

            var ItemResponse = await itemInterface.GetAllItemsAsync();
            if (ItemResponse.IsSuccessful)
            {
                var Items = JsonConvert.DeserializeObject<List<Item>>(ItemResponse.Content);
                supplier.SupplierItem = Items
                    .Select(p => new SelectListItem
                    {
                        Text = p.ItemName,
                        Value = p.Id.ToString()
                    })
                    .ToList();
            }

            var citiesResponse = await cityInterface.GetAllCitiesAsync();
            if (citiesResponse.IsSuccessful)
            {
                var cities = JsonConvert.DeserializeObject<List<City>>(citiesResponse.Content);
                supplier.Cities = cities
                    .Select(c => new SelectListItem
                    {
                        Text = c.Name,
                        Value = c.Id.ToString()
                    })
                    .ToList();
            }

            return supplier;
        }

        [HttpGet]
        public async Task<IActionResult> SupplierListing()
        {
            var response = await supplierInterface.GetAllSuppliersAsync();
            if (response.IsSuccessful)
            {
                var suppliers = JsonConvert.DeserializeObject<List<Supplier>>(response.Content);
                ViewBag.PageSize = new Dictionary<Int32, String> { { 0, "All" }, { 2, "2" }, { 4, "4" }};
                return View(suppliers);
            }
            else
            {
                return BadRequest(response.ErrorMessage);
            }
        }

        [HttpPost]
        public async Task<IActionResult> AddSupplier([FromForm] Supplier supplier)
        {
            if (ModelState.IsValid)
            {
                    var response = await supplierInterface.AddSupplier(supplier);
                if (response.IsSuccessful)
                {
                    var supplierDetail = JsonConvert.DeserializeObject<Supplier>(response.Content);
                    return RedirectToAction("SupplierListing", "Supplier");
                }
                else
                {
                    return BadRequest(response.ErrorMessage);
                }
            }
            return View(supplier);
        }
        [HttpPost]
        public async Task<IActionResult> UpdateSupplier([FromForm] Supplier supplier)
        {
            if (ModelState.IsValid)
            {
                var response = await supplierInterface.UpdateSupplier(supplier);
                if (response.IsSuccessful)
                {
                    return RedirectToAction("SupplierListing", "Supplier");
                }
                else
                {
                    return BadRequest(response.ErrorMessage);
                }
            }
            return View(supplier);
        }

        public async Task<IActionResult> DeleteSupplier(Guid id)
        {
            var response = await supplierInterface.DeleteSupplier(id);
            if (response.IsSuccessful)
            {
                return Ok(response.Content);
            }
            else
            {
                return BadRequest(response.ErrorMessage);
            }
        }
    }
}
