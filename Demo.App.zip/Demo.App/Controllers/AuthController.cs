﻿using Microsoft.AspNetCore.Mvc;
using Demo.App.Interfaces;
using Demo.App.Models;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Http;

namespace Demo.App.Controllers
{
    public class AuthController : Controller
    {
        private readonly IAuthInterface login;

        public AuthController(IAuthInterface login)
        {
            this.login = login;
        }

        public ActionResult Login()
        {
            return View();
        }

        public ActionResult ForgotPassword()
        {
            return View();
        }

        public ActionResult ResetPassowrd()
        {

            return View();
        }

        public ActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login", "Auth");
        }

        [HttpPost]
        public async Task<ActionResult> Login(Login model)
        {
            try
            {
                var response = await login.Login(model);

                if (response.IsSuccessful)
                {
                    var tokenObject = JsonConvert.DeserializeAnonymousType(response.Content, new Auth());
                    var token = tokenObject.Token;
                    var roleName = tokenObject.RoleName;
                    var userId = tokenObject.UserId;
                    var RoleId = tokenObject.RoleId;

                    var rolePagePermissionsJson = JsonConvert.SerializeObject(tokenObject.RolePagePermissions);
                    HttpContext.Session.SetString("RolePagePermissions", rolePagePermissionsJson);  
                    HttpContext.Session.SetString("Token", token);
                    HttpContext.Session.SetString("Role", roleName);
                    HttpContext.Session.SetString("userId", userId);
                    HttpContext.Session.SetString("RoleId", RoleId);


                    if (roleName == "SuperAdmin")
                    {
                        TempData["Login"] = "Login Successful";
                        return RedirectToAction("DashBoard", "Home");
                    }
                    else
                    {
                        TempData["Unauthorized"] = "Unauthorized";
                        return RedirectToAction("Login", "Auth");
                    }
                }
                else
                {
                    TempData["Unauthorized"] = "Invalid username or password";
                    return RedirectToAction("Login", "Auth");
                }
            }
            catch (Exception)
            {
                TempData["Unauthorized"] = "Invalid username or password";
                return RedirectToAction("Login", "Auth");
            }
        }
    }
}
