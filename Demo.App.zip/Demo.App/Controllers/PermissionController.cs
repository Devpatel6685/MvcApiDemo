﻿using Microsoft.AspNetCore.Mvc;
using Demo.App.Interfaces;
using Demo.App.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Demo.App.Controllers
{
    public class PermissionController : Controller
    {
        private readonly IPermissionInterface permissionInterface;

        public PermissionController(IPermissionInterface permission)
        {
            this.permissionInterface = permission;
        }

        [HttpGet]
        public async Task<IActionResult> PermissionDetails(Guid id)
        {
            var response = await permissionInterface.GetPermissionByIdAsync(id);
            if (response.IsSuccessful)
            {
                var permissionDetail = JsonConvert.DeserializeObject<Permission>(response.Content);
                return View(permissionDetail);
            }
            else
            {
                return NotFound();
            }
        }

        [HttpGet]
        public async Task<IActionResult> PermissionListing(int pageNumber = 1, int pageSize = 10)
        {
            var response = await permissionInterface.GetAllPermissionsAsync(pageNumber, pageSize);
            if (response.IsSuccessful)
            {
                var permissions = JsonConvert.DeserializeObject<List<Permission>>(response.Content);

                int totalCount = permissions.Count;
                int pageCount = (int)Math.Ceiling((double)totalCount / pageSize);
                int startIdx = (pageNumber - 1) * pageSize;
                var pagedPermissions = permissions.Skip(startIdx).Take(pageSize).ToList();

                ViewBag.PageNumber = pageNumber;
                ViewBag.PageCount = pageCount;
                ViewBag.PageSize = pageSize;

                return View(pagedPermissions);
            }
            else
            {
                return BadRequest(response.ErrorMessage);
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetAllPermissions()
        {
            var response = await permissionInterface.GetAllPermissionsAsync();
            if (response.IsSuccessful)
            {
                var permissions = JsonConvert.DeserializeObject<List<Permission>>(response.Content);
                return Json(permissions); // Return the permissions as JSON
            }
            else
            {
                return BadRequest(response.ErrorMessage);
            }
        }

        public async Task<IActionResult> AddPermission(Permission permission)
        {
            var response = await permissionInterface.AddPermission(permission);
            if (response.IsSuccessful)
            {
                return Ok(response.Content);
            }
            else
            {
                return BadRequest(response.ErrorMessage);
            }
        }

        public async Task<IActionResult> UpdatePermission(Permission permission)
        {
            var response = await permissionInterface.UpdatePermission(permission);
            if (response.IsSuccessful)
            {
                return RedirectToAction("Dashboard", "Home");
            }
            else
            {
                return BadRequest(response.ErrorMessage);
            }
        }

        public async Task<IActionResult> DeletePermission(Guid id)
        {
            var response = await permissionInterface.DeletePermission(id);
            if (response.IsSuccessful)
            {
                return Ok(response.Content);
            }
            else
            {
                return BadRequest(response.ErrorMessage);
            }
        }
    }
}
