﻿using Demo.Api.Interfaces;
using Demo.Api.Models.Dto;
using Microsoft.AspNetCore.Mvc;

namespace Demo.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : Controller
    {
        private readonly IAuthRepository authRepository;

        public AuthController(IAuthRepository authRepository)
        {
            this.authRepository = authRepository;
        }

        [Route("Login")]
        [HttpPost]
        public ActionResult<AuthDto> Login([FromBody] LoginDto login)
        {
            var loginResult = authRepository.Login(login);

            if (loginResult != null)
            {
                return Ok(loginResult);
            }
            else
            {
                return BadRequest("Invalid UserName or password");
            }
        }
    }
}
