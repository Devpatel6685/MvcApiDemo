﻿using Microsoft.AspNetCore.Mvc;
using Demo.Api.Interfaces;
using Demo.Api.Models.Dto;

namespace Demo.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SupplierController : ControllerBase
    {
        private readonly ISupplierRepository supplierRepository;

        public SupplierController(ISupplierRepository supplierRepository)
        {
            this.supplierRepository = supplierRepository;
        }

        [HttpGet("{id}")]
        public async Task<ActionResult> GetSupplierById(Guid id)
        {
            var supplierDetail = await supplierRepository.GetSupplierByIdAsync(id);
            if (supplierDetail == null)
            {
                return NotFound();
            }
            return Ok(supplierDetail);
        }

        [HttpGet("all")]
        public async Task<ActionResult> GetAllSuppliers()
        {
            var allSuppliers = await supplierRepository.GetAllSuppliersAsync();
            return Ok(allSuppliers);
        }

        [HttpPost("add")]
        public async Task<ActionResult> AddSupplier(SupplierDto supplier)
        {
            var Supplier = await supplierRepository.AddSupplierAsync(supplier);
            return Ok(Supplier);
        }

        [HttpPut("update/{id}")]
        public async Task<IActionResult> UpdateSupplier(Guid id, SupplierDto supplier)
        {
            await supplierRepository.UpdateSupplierAsync(id, supplier);
            return Ok("Supplier Updated successfully.");
        }

        [HttpDelete("delete/{id}")]
        public async Task<IActionResult> DeleteSupplier(Guid id)
        {
            await supplierRepository.DeleteSupplierAsync(id);
            return Ok("Supplier deleted successfully.");
        }
    }
}
