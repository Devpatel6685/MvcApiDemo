﻿using Microsoft.AspNetCore.Mvc;
using Demo.Api.Interfaces;
using Demo.Api.Models;
using System;
using System.Threading.Tasks;

namespace Demo.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PermissionController : ControllerBase
    {
        private readonly IPermissionRepository permissionRepository;

        public PermissionController(IPermissionRepository permissionRepository)
        {
            this.permissionRepository = permissionRepository;
        }

        [HttpGet("{id}")]
        public async Task<ActionResult> GetPermissionById(Guid id)
        {
            var permission = await permissionRepository.GetPermissionByIdAsync(id);
            if (permission == null)
            {
                return NotFound();
            }
            return Ok(permission);
        }

        [HttpGet("all")]
        public async Task<ActionResult> GetAllPermissions(int pageNumber = 1, int pageSize = 10)
        {
            var allPermissions = await permissionRepository.GetAllPermissionsAsync(pageNumber, pageSize);
            return Ok(allPermissions);
        }

        [HttpPost("add")]
        public async Task<ActionResult> AddPermission(Permission permission)
        {
            await permissionRepository.AddPermissionAsync(permission);
            return Ok("Permission added successfully.");
        }

        [HttpPut("update/{id}")]
        public async Task<IActionResult> UpdatePermission(Guid id, Permission permission)
        {
            await permissionRepository.UpdatePermissionAsync(id, permission);
            return Ok();
        }

        [HttpDelete("delete/{id}")]
        public async Task<IActionResult> DeletePermission(Guid id)
        {
            await permissionRepository.DeletePermissionAsync(id);
            return Ok("Permission deleted successfully.");
        }
    }
}
