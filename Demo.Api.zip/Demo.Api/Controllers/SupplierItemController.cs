﻿using Microsoft.AspNetCore.Mvc;
using Demo.Api.Interfaces;
using Demo.Api.Models.Dto;
using System;
using System.Threading.Tasks;

namespace Demo.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SupplierItemController : ControllerBase
    {
        private readonly ISupplierItemRepository supplierItemRepository;

        public SupplierItemController(ISupplierItemRepository supplierItemRepository)
        {
            this.supplierItemRepository = supplierItemRepository;
        }

        [HttpGet("{id}")]
        public async Task<ActionResult> GetSupplierItemById(Guid id)
        {
            var supplierItemDetail = await supplierItemRepository.GetSupplierItemByIdAsync(id);
            if (supplierItemDetail == null)
            {
                return NotFound();
            }
            return Ok(supplierItemDetail);
        }

        [HttpGet("all")]
        public async Task<ActionResult> GetAllSupplierItems(int pageNumber = 1, int pageSize = 10)
        {
            var allSupplierItems = await supplierItemRepository.GetAllSupplierItemsAsync(pageNumber, pageSize);
            return Ok(allSupplierItems);
        }

        [HttpPost("add")]
        public async Task<ActionResult> AddSupplierItem(SupplierItemDto supplierItem)
        {
            await supplierItemRepository.AddSupplierItemAsync(supplierItem);
            return Ok("Supplier item added successfully.");
        }
        [HttpGet("getitemsbysupplier/{supplierId}")]
        public async Task<ActionResult> GetItemIdsBySupplierId(Guid supplierId)
        {
            var itemIds = await supplierItemRepository.GetItemIdsBySupplierIdAsync(supplierId);
            return Ok(itemIds);
        }

        [HttpPut("update/{id}")]
        public async Task<IActionResult> UpdateSupplierItem(Guid id, SupplierItemDto supplierItem)
        {
            await supplierItemRepository.UpdateSupplierItemAsync(id, supplierItem);
            return Ok("Supplier item updated successfully.");
        }

        [HttpDelete("delete/{id}")]
        public async Task<IActionResult> DeleteSupplierItem(Guid id)
        {
            await supplierItemRepository.DeleteSupplierItemAsync(id);
            return Ok("Supplier item deleted successfully.");
        }
    }
}
