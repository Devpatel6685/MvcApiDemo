﻿using Microsoft.AspNetCore.Mvc;
using Demo.Api.Interfaces;
using Demo.Api.Models.Dto;

namespace Demo.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        private readonly ICustomerRepository customerRepository;

        public CustomerController(ICustomerRepository customerRepository)
        {
            this.customerRepository = customerRepository;
        }

        [HttpGet("{id}")]
        public async Task<ActionResult> GetCustomerById(Guid id)
        {
            var customerDetail = await customerRepository.GetCustomerByIdAsync(id);
            if (customerDetail == null)
            {
                return NotFound();
            }
            return Ok(customerDetail);
        }

        [HttpGet("all")]
        public async Task<ActionResult> GetAllCustomers()
        {
            var allCustomers = await customerRepository.GetAllCustomersAsync();
            return Ok(allCustomers);
        }

        [HttpPost("add")]
        public async Task<ActionResult> AddCustomer(CustomerDto customer)
        {
            await customerRepository.AddCustomerAsync(customer);
            return Ok("Customer added successfully.");
        }

        [HttpPut("update/{id}")]
        public async Task<IActionResult> UpdateCustomer(Guid id, CustomerDto customer)
        {
            await customerRepository.UpdateCustomerAsync(id, customer);
            return Ok("Customer Updated successfully.");
        }

        [HttpDelete("delete/{id}")]
        public async Task<IActionResult> DeleteCustomer(Guid id)
        {
            await customerRepository.DeleteCustomerAsync(id);
            return Ok("Customer deleted successfully.");
        }
    }
}
