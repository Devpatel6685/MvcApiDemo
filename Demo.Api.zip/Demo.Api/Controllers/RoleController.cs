﻿using Microsoft.AspNetCore.Mvc;
using Demo.Api.Interfaces;
using Demo.Api.Models.Dto;

namespace Demo.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RoleController : ControllerBase
    {
        private readonly IRoleRepository roleRepository;

        public RoleController(IRoleRepository roleRepository)
        {
            this.roleRepository = roleRepository;
        }

        [HttpGet("{id}")]
        public async Task<ActionResult> GetRoleById(Guid id)
        {
            var roleDetail = await roleRepository.GetRoleByIdAsync(id);
            if (roleDetail == null)
            {
                return NotFound();
            }
            return Ok(roleDetail);
        }

        [HttpGet("all")]
        public async Task<ActionResult> GetAllRoles()
        {
            var allRoles = await roleRepository.GetAllRolesAsync();
            return Ok(allRoles);
        }
        [HttpPost("add")]
        public async Task<ActionResult> AddRole(RoleDto role)
        {
            await roleRepository.AddRoleAsync(role);
            return Ok("Role added successfully.");
        }

        [HttpPut("update/{id}")]
        public async Task<IActionResult> UpdateRole(Guid id, RoleDto role)
        {
            await roleRepository.UpdateRoleAsync(id, role);
            return Ok("Role Updated successfully.");
        }

        [HttpDelete("delete/{id}")]
        public async Task<IActionResult> DeleteRole(Guid id)
        {
            await roleRepository.DeleteRoleAsync(id);
            return Ok("Role deleted successfully.");
        }
    }
}
