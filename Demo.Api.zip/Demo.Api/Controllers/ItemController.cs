﻿using Microsoft.AspNetCore.Mvc;
using Demo.Api.Interfaces;
using Demo.Api.Models;
using Demo.Api.Models.Dto;
using System;
using System.Threading.Tasks;

namespace Demo.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ItemController : Controller
    {
        private readonly IItemRepository itemRepository;

        public ItemController(IItemRepository itemRepository)
        {
            this.itemRepository = itemRepository;
        }

        [HttpGet("{id}")]
        public async Task<ActionResult> GetItemById(Guid id)
        {
            var item = await itemRepository.GetItemByIdAsync(id);
            if (item == null)
            {
                return NotFound();
            }
            return Ok(item);
        }

        [HttpGet("all")]
        public async Task<ActionResult> GetAllItems(int pageNumber = 1, int pageSize = 10)
        {
            var allItems = await itemRepository.GetAllItemsAsync(pageNumber, pageSize);
            return Ok(allItems);
        }

        [HttpPost("add")]
        public async Task<ActionResult> AddItem(ItemDto item)
        {
            await itemRepository.AddItemAsync(item);
            return Ok("Item added successfully.");
        }

        [HttpPut("update/{id}")]
        public async Task<IActionResult> UpdateItem(Guid id, ItemDto item)
        {
            await itemRepository.UpdateItemAsync(id, item);
            return Ok();
        }

        [HttpDelete("delete/{id}")]
        public async Task<IActionResult> DeleteItem(Guid id)
        {
            await itemRepository.DeleteItemAsync(id);
            return Ok("Item deleted successfully.");
        }
    }
}
