﻿using Microsoft.AspNetCore.Mvc;
using Demo.Api.Interfaces;
using Demo.Api.Models.Dto;
using System;
using System.Threading.Tasks;

namespace Demo.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RolePagePermissionController : ControllerBase
    {
        private readonly IRolePagePermissionRepository _rolePagePermissionRepository;

        public RolePagePermissionController(IRolePagePermissionRepository rolePagePermissionRepository)
        {
            _rolePagePermissionRepository = rolePagePermissionRepository;
        }

        [HttpGet("{id}")]
        public async Task<ActionResult> GetRolePagePermissionById(Guid id)
        {
            var rolePagePermissionDetail = await _rolePagePermissionRepository.GetRolePagePermissionByIdAsync(id);
            if (rolePagePermissionDetail == null)
            {
                return NotFound();
            }
            return Ok(rolePagePermissionDetail);
        }

        [HttpGet("all")]
        public async Task<ActionResult> GetAllRolePagePermissions()
        {
            var allRolePagePermissions = await _rolePagePermissionRepository.GetAllRolePagePermissionsAsync();
            return Ok(allRolePagePermissions);
        }

        [HttpPost("add")]
        public async Task<ActionResult> AddRolePagePermission(RolePagePermissionDto rolePagePermission)
        {
            await _rolePagePermissionRepository.AddRolePagePermissionAsync(rolePagePermission);
            return Ok("RolePagePermission added successfully.");
        }

        [HttpPut("update/{id}")]
        public async Task<IActionResult> UpdateRolePagePermission(Guid id, RolePagePermissionDto rolePagePermission)
        {
            await _rolePagePermissionRepository.UpdateRolePagePermissionAsync(id, rolePagePermission);
            return Ok("RolePagePermission updated successfully.");
        }

        [HttpDelete("delete/{id}")]
        public async Task<IActionResult> DeleteRolePagePermission(Guid id)
        {
            await _rolePagePermissionRepository.DeleteRolePagePermissionAsync(id);
            return Ok("RolePagePermission deleted successfully.");
        }
    }
}
