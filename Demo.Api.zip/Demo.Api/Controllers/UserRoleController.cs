﻿using Microsoft.AspNetCore.Mvc;
using Demo.Api.Interfaces;
using Demo.Api.Models;

namespace Demo.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserRoleController : ControllerBase
    {
        private readonly IUserRoleRepository userRoleRepository;

        public UserRoleController(IUserRoleRepository userRoleRepository)
        {
            this.userRoleRepository = userRoleRepository;
        }

        [HttpGet("{id}")]
        public async Task<ActionResult> GetUserRoleById(Guid id)
        {
            var userRoleDetail = await userRoleRepository.GetUserRoleByIdAsync(id);
            if (userRoleDetail == null)
            {
                return NotFound();
            }
            return Ok(userRoleDetail);
        }

        [HttpPost("add")]
        public async Task<ActionResult> AddUserRole(UserRole userRole)
        {
            await userRoleRepository.AddUserRoleAsync(userRole);
            return Ok("UserRole added successfully.");
        }

        [HttpPut("update/{id}")]
        public async Task<IActionResult> UpdateUserRole(Guid id, UserRole userRole)
        {  
            await userRoleRepository.UpdateUserRoleAsync(id, userRole);
            return Ok("UserRole Updated successfully.");
        }

        [HttpDelete("delete/{id}")]
        public async Task<IActionResult> DeleteUserRole(Guid id)
        {
            await userRoleRepository.DeleteUserRoleAsync(id);
            return Ok("UserRole deleted successfully.");
        }
    }
}
