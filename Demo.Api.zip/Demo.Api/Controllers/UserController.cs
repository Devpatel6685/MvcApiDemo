﻿using Microsoft.AspNetCore.Mvc;
using Demo.Api.Interfaces;
using Demo.Api.Models.Dto;

namespace Demo.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : Controller
    {
        private readonly IUserRepository userRepository;
        public UserController(IUserRepository userRepository)
        {
            this.userRepository = userRepository;
        }

        [HttpGet("{id}")]
        public async Task<ActionResult> GetUserById(Guid id)
        {
            var userDetail = await userRepository.GetUserByIdAsync(id);
            if (userDetail == null)
            {
                return NotFound();
            }
            return Ok(userDetail);
        }

        [HttpGet("all")]
        public async Task<ActionResult> GetAllUsers()
        {
            var allUsers = await userRepository.GetAllUsersAsync();
            return Ok(allUsers);
        }

        [HttpPost("add")]
        public async Task<ActionResult> AddUser(UserDto user)
        {
            await userRepository.AddUserAsync(user);
            return Ok("User added successfully.");
        }

        [HttpPut("update/{id}")]
        public async Task<IActionResult> UpdateUser(Guid id, UserDto user)
        {
            await userRepository.UpdateUserAsync(id, user);
            return Ok();
        }

        [HttpDelete("delete/{id}")]
        public async Task<IActionResult> DeleteUser(Guid id)
        {
            await userRepository.DeleteUserAsync(id);
            return Ok("User deleted successfully.");
        }
    }
}
