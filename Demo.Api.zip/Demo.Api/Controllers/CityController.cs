﻿using Microsoft.AspNetCore.Mvc;
using Demo.Api.Interfaces;
using Demo.Api.Models;
using Demo.Api.Models.Dto;
using System;
using System.Threading.Tasks;

namespace Demo.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CityController : Controller
    {
        private readonly ICityRepository cityRepository;

        public CityController(ICityRepository cityRepository)
        {
            this.cityRepository = cityRepository;
        }

        [HttpGet("{id}")]
        public async Task<ActionResult> GetCityById(Guid id)
        {
            var city = await cityRepository.GetCityByIdAsync(id);
            if (city == null)
            {
                return NotFound();
            }
            return Ok(city);
        }

        [HttpGet("all")]
        public async Task<ActionResult> GetAllCities(int pageNumber = 1, int pageSize = 10)
        {
            var allCities = await cityRepository.GetAllCitiesAsync(pageNumber, pageSize);
            return Ok(allCities);
        }

        [HttpPost("add")]
        public async Task<ActionResult> AddCity(CityDto city)
        {
            await cityRepository.AddCityAsync(city);
            return Ok("City added successfully.");
        }

        [HttpPut("update/{id}")]
        public async Task<IActionResult> UpdateCity(Guid id, CityDto city)
        {
            await cityRepository.UpdateCityAsync(id, city);
            return Ok();
        }

        [HttpDelete("delete/{id}")]
        public async Task<IActionResult> DeleteCity(Guid id)
        {
            await cityRepository.DeleteCityAsync(id);
            return Ok("City deleted successfully.");
        }
    }
}
