﻿using Microsoft.AspNetCore.Mvc;
using Demo.Api.Interfaces;
using Demo.Api.Models.Dto;

namespace Demo.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PageController : ControllerBase
    {
        private readonly IPageRepository pageRepository;

        public PageController(IPageRepository pageRepository)
        {
            this.pageRepository = pageRepository;
        }

        [HttpGet("{id}")]
        public async Task<ActionResult> GetPageById(Guid id)
        {
            var pageDetail = await pageRepository.GetPageByIdAsync(id);
            if (pageDetail == null)
            {
                return NotFound();
            }
            return Ok(pageDetail);
        }

        [HttpGet("all")]
        public async Task<ActionResult> GetAllPages()
        {
            var allUsers = await pageRepository.GetAllPagesAsync();
            return Ok(allUsers);
        }

        [HttpPost("add")]
        public async Task<ActionResult> AddPage(PageDto page)
        {
            await pageRepository.AddPageAsync(page);
            return Ok("Page added successfully.");
        }

        [HttpPut("update/{id}")]
        public async Task<IActionResult> UpdatePage(Guid id, PageDto page)
        {
            await pageRepository.UpdatePageAsync(id, page);
            return Ok("Page Updated successfully.");
        }

        [HttpDelete("delete/{id}")]
        public async Task<IActionResult> DeletePage(Guid id)
        {
            await pageRepository.DeletePageAsync(id);
            return Ok("Page deleted successfully.");
        }
    }
}
