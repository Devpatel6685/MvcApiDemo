﻿using Demo.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace Demo.Api.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {

        }
        public DbSet<User> Users { get; set; }

        public DbSet<Role> Roles { get; set; }

        public DbSet<Permission> Permissions { get; set; }

        public DbSet<UserRole> UserRoles { get; set; }

        public DbSet<Customer> Customers { get; set; }

        public DbSet<Supplier> Suppliers { get; set; }

        public DbSet<SupplierItem> SupplierItems { get; set; }

        public DbSet<Item> Items { get; set; }

        public DbSet<City> Cities { get; set; }


        public DbSet<Page> Pages { get; set; }

        public DbSet<RolePagePermission> RolePagePermissions { get; set; }

        public DbSet<EmailToken> EmailTokens { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            var userId = Guid.NewGuid();
            var roleId = Guid.NewGuid();

            modelBuilder.Entity<User>().HasData(
                new User
                {
                    Id = userId,
                    Name = "Super Admin",
                    Mobile = "1234567890",
                    Address = "DefaultAddress",
                    Email = "superadmin@tatvasoft.com",
                    UserName = "super_admin",
                    Password = "Tatva@123",
                    CreatedOn = DateTime.Now,
                    CreatedBy = userId,
                    UpdatedBy = userId,
                    UpdatedOn = DateTime.Now,
                    DeletedBy = null,
                    DeletedOn = null
                }
            );

            modelBuilder.Entity<Role>().HasData(
                new Role
                {
                    Id = roleId,
                    Name = "SuperAdmin",
                    CreatedOn = DateTime.Now,
                    CreatedBy = userId,
                    UpdatedBy = userId,
                    UpdatedOn = DateTime.Now,
                    DeletedBy = null,
                    DeletedOn = null
                }
            );

            modelBuilder.Entity<UserRole>().HasData(
               new UserRole
               {
                   Id = Guid.NewGuid(),
                   UserId = userId,
                   RoleId = roleId,
                   CreatedOn = DateTime.Now,
                   CreatedBy = userId,
                   UpdatedBy = userId,
                   UpdatedOn = DateTime.Now,
                   DeletedBy = null,
                   DeletedOn = null
               }
           );

        }
    }
}
