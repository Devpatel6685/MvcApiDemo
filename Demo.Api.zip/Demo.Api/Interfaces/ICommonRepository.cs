﻿using System.Linq.Expressions;
using Demo.Api.Models.Common;

namespace Demo.Api.Interfaces
{
    public interface ICommonRepository<T> where T : DbEntity
    {
        Task<IEnumerable<T>> GetAllAsync();

        Task<T> GetByIdAsync(Guid id);

        Task<T> FindByConditionAsync(Expression<Func<T, bool>> predicate);

        void Add(T entity);

        void Update(T entity);

        Task Delete(Guid id);

        Task<bool> SaveChangesAsync();
    }
}
