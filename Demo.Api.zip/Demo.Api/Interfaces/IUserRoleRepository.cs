﻿using Demo.Api.Models;

namespace Demo.Api.Interfaces
{
    public interface IUserRoleRepository
    {
        Task<UserRole> GetUserRoleByIdAsync(Guid id);

        Task AddUserRoleAsync(UserRole userRole);

        Task UpdateUserRoleAsync(Guid id, UserRole userRole);

        Task DeleteUserRoleAsync(Guid id);
    }
}
