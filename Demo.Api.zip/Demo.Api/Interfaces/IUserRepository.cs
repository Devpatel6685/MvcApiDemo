﻿using Demo.Api.Models;
using Demo.Api.Models.Dto;

namespace Demo.Api.Interfaces
{
    public interface IUserRepository
    {
        Task<IEnumerable<User>> GetAllUsersAsync();

        Task<User> GetUserByIdAsync(Guid id);

        Task AddUserAsync(UserDto user);

        Task UpdateUserAsync(Guid id, UserDto user);

        Task DeleteUserAsync(Guid id);

    }
}
