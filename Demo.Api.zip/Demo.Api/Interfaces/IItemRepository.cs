﻿using Demo.Api.Models;
using Demo.Api.Models.Dto;

namespace Demo.Api.Interfaces
{
    public interface IItemRepository
    {
        Task<IEnumerable<Item>> GetAllItemsAsync(int pageNumber = 1, int pageSize = 10);

        Task<Item> GetItemByIdAsync(Guid id);

        Task AddItemAsync(ItemDto item);

        Task UpdateItemAsync(Guid id, ItemDto item);

        Task DeleteItemAsync(Guid id);

    }
}
