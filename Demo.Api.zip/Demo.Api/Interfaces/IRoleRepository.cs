﻿using Demo.Api.Models;
using Demo.Api.Models.Dto;

namespace Demo.Api.Interfaces
{
    public interface IRoleRepository
    {
        Task<IEnumerable<Role>> GetAllRolesAsync();

        Task<Role> GetRoleByIdAsync(Guid id);

        Task AddRoleAsync(RoleDto role);

        Task UpdateRoleAsync(Guid id, RoleDto role);

        Task DeleteRoleAsync(Guid id);
    }
}
