﻿using Demo.Api.Models;
using Demo.Api.Models.Dto;

namespace Demo.Api.Interfaces
{
    public interface ICustomerRepository
    {
        Task<IEnumerable<Customer>> GetAllCustomersAsync();

        Task<Customer> GetCustomerByIdAsync(Guid id);

        Task AddCustomerAsync(CustomerDto customer);

        Task UpdateCustomerAsync(Guid id, CustomerDto customer);

        Task DeleteCustomerAsync(Guid id);
    }
}
