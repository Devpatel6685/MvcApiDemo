﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Demo.Api.Models;
using Demo.Api.Models.Dto;

namespace Demo.Api.Interfaces
{
    public interface ISupplierItemRepository
    {
        Task<IEnumerable<SupplierItem>> GetAllSupplierItemsAsync(int pageNumber, int pageSize);

        Task<SupplierItem> GetSupplierItemByIdAsync(Guid id);

        Task<IEnumerable<Guid>> GetItemIdsBySupplierIdAsync(Guid supplierId);

        Task AddSupplierItemAsync(SupplierItemDto supplierItem);

        Task UpdateSupplierItemAsync(Guid id, SupplierItemDto supplierItem);

        Task DeleteSupplierItemAsync(Guid id);
    }
}
