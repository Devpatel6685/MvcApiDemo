﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Demo.Api.Models;
using Demo.Api.Models.Dto;

namespace Demo.Api.Interfaces
{
    public interface IRolePagePermissionRepository
    {
        Task<IEnumerable<RolePagePermission>> GetAllRolePagePermissionsAsync();
        Task<List<RolePagePermission>> GetRolePagePermissionByIdAsync(Guid roleId);
        Task AddRolePagePermissionAsync(RolePagePermissionDto rolePagePermission);

        Task UpdateRolePagePermissionAsync(Guid id, RolePagePermissionDto rolePagePermission);

        Task DeleteRolePagePermissionAsync(Guid id);
    }
}
