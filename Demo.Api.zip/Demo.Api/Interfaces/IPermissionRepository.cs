﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Demo.Api.Models;

namespace Demo.Api.Interfaces
{
    public interface IPermissionRepository
    {
        Task<IEnumerable<Permission>> GetAllPermissionsAsync(int pageNumber = 1, int pageSize = 10);

        Task<Permission> GetPermissionByIdAsync(Guid id);

        Task AddPermissionAsync(Permission permission);

        Task UpdatePermissionAsync(Guid id, Permission permission);

        Task DeletePermissionAsync(Guid id);
    }
}
