﻿using Demo.Api.Models.Dto;

namespace Demo.Api.Interfaces
{
    public interface IAuthRepository
    {
        AuthDto Login(LoginDto model);
    }
}
