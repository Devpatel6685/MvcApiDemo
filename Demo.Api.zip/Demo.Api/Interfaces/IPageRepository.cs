﻿using Demo.Api.Models;
using Demo.Api.Models.Dto;

namespace Demo.Api.Interfaces
{
    public interface IPageRepository
    {
        Task<IEnumerable<Page>> GetAllPagesAsync();
        Task<Page> GetPageByIdAsync(Guid id);

        Task AddPageAsync(PageDto page);

        Task UpdatePageAsync(Guid id, PageDto page);

        Task DeletePageAsync(Guid id);
    }
}
