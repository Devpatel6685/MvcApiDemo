﻿using Demo.Api.Models;
using Demo.Api.Models.Dto;

namespace Demo.Api.Interfaces
{
    public interface ISupplierRepository
    {
        Task<IEnumerable<Supplier>> GetAllSuppliersAsync();

        Task<Supplier> GetSupplierByIdAsync(Guid id);

        Task<Supplier> AddSupplierAsync(SupplierDto supplier);

        Task UpdateSupplierAsync(Guid id, SupplierDto supplier);

        Task DeleteSupplierAsync(Guid id);
    }
}
