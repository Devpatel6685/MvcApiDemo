﻿using Demo.Api.Models;
using Demo.Api.Models.Dto;

namespace Demo.Api.Interfaces
{
    public interface ICityRepository
    {
        Task<IEnumerable<City>> GetAllCitiesAsync(int pageNumber = 1, int pageSize = 10);

        Task<City> GetCityByIdAsync(Guid id);

        Task AddCityAsync(CityDto city);

        Task UpdateCityAsync(Guid id, CityDto city);

        Task DeleteCityAsync(Guid id);
    }
}
