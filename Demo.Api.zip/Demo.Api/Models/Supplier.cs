﻿using Demo.Api.Models.Common;
using System.ComponentModel.DataAnnotations.Schema;

namespace Demo.Api.Models
{
    public class Supplier : DbEntity
    {
        public string Name { get; set; }

        public string Address { get; set; }
        [Column(TypeName = "decimal(10,2)")]
        public decimal ItemPrice { get; set; }

        [ForeignKey("City")]
        public Guid CityId { get; set; }

        public string ZIPCode { get; set; }

        public string Country { get; set; }

        public string Mobile { get; set; }

        public virtual City? City { get; set; }

        public virtual ICollection<SupplierItem>? SupplierItems { get; set; }

    }

}
