﻿namespace Demo.Api.Models.Dto
{
    public class AuthDto
    {
        public string Token { get; set; }

        public string RoleName { get; set; }

        public string UserId { get; set; }

        public string RoleId { get; set; }

        public Dictionary<string, List<string>> RolePagePermissions { get; set; }
    }
}
