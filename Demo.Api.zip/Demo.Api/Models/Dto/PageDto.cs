﻿using System.ComponentModel.DataAnnotations;

namespace Demo.Api.Models.Dto
{
    public class PageDto
    {        
        public string Name { get; set; }
    }
}
