﻿namespace Demo.Api.Models.Dto
{
    public class RolePagePermissionDto
    {
        public Guid Id { get; set; }
        public Guid PermissionId { get; set; }
     
        public Guid RoleId { get; set; }
       
        public Guid PageId { get; set; }
    }
}
