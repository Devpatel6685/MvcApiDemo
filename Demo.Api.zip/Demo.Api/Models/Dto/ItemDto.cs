﻿namespace Demo.Api.Models.Dto
{
    public class ItemDto
    {
        public Guid Id { get; set; }
        public string ItemName { get; set; }
        public string Description { get; set; }
    }
}
