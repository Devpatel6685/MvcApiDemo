﻿namespace Demo.Api.Models.Dto
{
    public class SupplierDto
    {
        public string Name { get; set; }

        public string Address { get; set; }
        public decimal ItemPrice { get; set; }

        public string CityId { get; set; }

        public string ZIPCode { get; set; }

        public string Country { get; set; }

        public string Mobile { get; set; }

        public List<string>? SelectedSupplierItems { get; set; }

    }
}
