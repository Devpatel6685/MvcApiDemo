﻿namespace Demo.Api.Models.Dto
{
    public class RoleDto
    {
        public string Name { get; set; }

    }
}
