﻿namespace Demo.Api.Models.Dto
{
    public class CityDto
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
    }
}
