﻿namespace Demo.Api.Models.Dto
{
    public class ResetPasswordDto
    {
        public string Password { get; set; }

        public string Token { get; set; }
    }
}
