﻿namespace Demo.Api.Models.Dto
{
    public class SupplierItemDto
    {
        public Guid ItemId { get; set; }   
        public Guid SupplierId { get; set; }
        public List<string>? SelectedSupplierItems { get; set; }

    }
}
