﻿using Demo.Api.Models.Common;

namespace Demo.Api.Models
{
    public class Customer : DbEntity
    {
        public string Name { get; set; }

        public string Address { get; set; }

        public string City { get; set; }

        public string ZIPCode { get; set; }

        public string Country { get; set; }

        public string Mobile { get; set; }

    }
}
