﻿using Demo.Api.Models.Common;
using System.ComponentModel.DataAnnotations.Schema;

namespace Demo.Api.Models
{
    public class SupplierItem : DbEntity
    {
        [ForeignKey("Item")]
        public Guid ItemId { get; set; }

        [ForeignKey("Supplier")]
        public Guid SupplierId { get; set; }

        public virtual Item? Item { get; set; }

    }
}