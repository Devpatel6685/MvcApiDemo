﻿using Demo.Api.Models.Common;

namespace Demo.Api.Models
{
    public class EmailToken : DbEntity
    {
        public string Email { get; set; }

        public string Token { get; set; }

    }
}
