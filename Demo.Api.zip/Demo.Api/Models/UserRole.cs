﻿using System.ComponentModel.DataAnnotations.Schema;
using Demo.Api.Models.Common;

namespace Demo.Api.Models
{
    public class UserRole : DbEntity
    {
        [ForeignKey("Users")]
        public Guid UserId { get; set; }

        [ForeignKey("Roles")]
        public Guid RoleId { get; set; }

        public virtual Role? Role { get; set; }

        public virtual User? User { get; set; }
    }
}
