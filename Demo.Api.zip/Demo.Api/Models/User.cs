﻿using Demo.Api.Models.Common;

namespace Demo.Api.Models
{
    public class User : DbEntity
    {
        public string Name { get; set; }

        public string Mobile { get; set; }

        public string Address { get; set; }

        public string Email { get; set; }

        public string UserName { get; set; }

        public string Password { get; set; }

        public virtual ICollection<UserRole>? UserRoles { get; set; }
    }
}
