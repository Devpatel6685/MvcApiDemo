﻿using System.ComponentModel.DataAnnotations;
using Demo.Api.Models.Common;

namespace Demo.Api.Models
{
    public class Role : DbEntity
    {
        public string Name { get; set; }

        public virtual ICollection<UserRole>? UserRoles { get; set; }
    }
}

