﻿using System.ComponentModel.DataAnnotations;
using Demo.Api.Models.Common;

namespace Demo.Api.Models
{
    public class Page : DbEntity
    {
        public string Name { get; set; }
    }
}
