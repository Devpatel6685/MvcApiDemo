﻿using Demo.Api.Models.Common;
using System.ComponentModel.DataAnnotations.Schema;

namespace Demo.Api.Models
{
    public class RolePagePermission : DbEntity
    {
        [ForeignKey("Permissions")]
        public Guid PermissionId { get; set; }

        [ForeignKey("Roles")]
        public Guid RoleId { get; set; }

        [ForeignKey("Pages")]
        public Guid PageId { get; set; }

        public virtual Role? Role { get; set; }

        public virtual Page? Page { get; set; }

        public virtual Permission? Permission { get; set; }
    }
}
