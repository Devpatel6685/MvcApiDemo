﻿using Demo.Api.Models.Common;

namespace Demo.Api.Models
{
    public class City : DbEntity
    {
        public string Name { get; set; }

        public string Description { get; set; }

    }
}