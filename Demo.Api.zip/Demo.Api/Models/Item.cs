﻿using Demo.Api.Models.Common;
namespace Demo.Api.Models
{
    public class Item : DbEntity
    {   
        public string ItemName { get; set; }
        public string Description { get; set; }
    }
}