﻿using AutoMapper;
using Demo.Api.Models;
using Demo.Api.Models.Dto;

namespace Demo.Api.Mapping
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<UserDto, User>().ReverseMap();
            CreateMap<CustomerDto, Customer>().ReverseMap();
            CreateMap<RoleDto, Role>().ReverseMap();
            CreateMap<PageDto, Page>().ReverseMap();
            CreateMap<SupplierDto, Supplier>().ReverseMap();
            CreateMap<SupplierItemDto, SupplierItem>().ReverseMap();
            CreateMap<RolePagePermissionDto, RolePagePermission>().ReverseMap();
            CreateMap<PermissionDto, Permission>().ReverseMap();

        }
    }
}
