﻿using Demo.Api.Models;

namespace Demo.Api.Repository
{
    public interface ISupplierRepository
    {
        Task<Supplier> GetSupplierByIdAsync(Guid id);

        Task AddSupplierAsync(Supplier supplier);

        Task UpdateSupplierAsync(Guid id, Supplier supplier);

        Task DeleteSupplierAsync(Guid id);
    }
}
