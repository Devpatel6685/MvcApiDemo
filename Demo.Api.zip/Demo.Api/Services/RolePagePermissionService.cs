﻿using AutoMapper;
using Demo.Api.Data;
using Demo.Api.Interfaces;
using Demo.Api.Models;
using Demo.Api.Models.Dto;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Demo.Api.Services
{
    public class RolePagePermissionService : IRolePagePermissionRepository
    {
        private readonly ICommonRepository<RolePagePermission> _commonRepository;
        private readonly ApplicationDbContext applicationDbContext;

        private IMapper _mapper;

        public RolePagePermissionService(ApplicationDbContext applicationDbContext,ICommonRepository<RolePagePermission> commonRepository, IMapper mapper)
        {   
            this.applicationDbContext = applicationDbContext;
            _commonRepository = commonRepository;
            _mapper = mapper;
        }

        public async Task<List<RolePagePermission>> GetRolePagePermissionByIdAsync(Guid roleId)
        {
            var rolePagePermissions = await applicationDbContext.RolePagePermissions.Where(s => s.RoleId == roleId && s.DeletedOn == null).ToListAsync();
            return rolePagePermissions;
        }


        public async Task<IEnumerable<RolePagePermission>> GetAllRolePagePermissionsAsync()
        {
            var rolepagepermission = await applicationDbContext.RolePagePermissions
                .Include(s => s.Role)  
                .Include(s => s.Page)
                .Include(s => s.Permission)
                .Where(s => s.DeletedOn == null)
                .ToListAsync();
            //var rolePagePermissions = await _commonRepository.GetAllAsync();
            return rolepagepermission;
        }

        public async Task AddRolePagePermissionAsync(RolePagePermissionDto rolePagePermissionDto)
        {
            var rolePagePermission = _mapper.Map<RolePagePermission>(rolePagePermissionDto);
            _commonRepository.Add(rolePagePermission);
            await _commonRepository.SaveChangesAsync();
        }

        public async Task UpdateRolePagePermissionAsync(Guid id, RolePagePermissionDto rolePagePermissionDto)
        {
            var existingRolePagePermission = await _commonRepository.GetByIdAsync(id);
            if (existingRolePagePermission == null)
            {
                throw new Exception("RolePagePermission not found.");
            }

            var rolePagePermission = _mapper.Map<RolePagePermission>(rolePagePermissionDto);

           
            _commonRepository.Update(existingRolePagePermission);
            await _commonRepository.SaveChangesAsync();
        }
        public async  Task DeleteRolePagePermissionAsync(Guid id)
        {
            var rolePagePermissionsToDelete = await applicationDbContext.RolePagePermissions
                .Where(s => s.RoleId == id)
                .ToListAsync();

            if (rolePagePermissionsToDelete.Count == 0)
            {
                throw new Exception("No RolePagePermissions found with the specified PermissionId.");
            }

            foreach (var rolePagePermissionToDelete in rolePagePermissionsToDelete)
            {
                _commonRepository.Delete(rolePagePermissionToDelete.Id); 
            }

            await _commonRepository.SaveChangesAsync();
        }




    }
}
