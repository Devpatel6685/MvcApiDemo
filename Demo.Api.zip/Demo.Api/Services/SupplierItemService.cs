﻿using AutoMapper;
using Demo.Api.Interfaces;
using Demo.Api.Models;
using Demo.Api.Models.Dto;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Demo.Api.Services
{
    public class SupplierItemService : ISupplierItemRepository
    {
        private readonly ICommonRepository<SupplierItem> commonRepository;
        private IMapper mapper;

        public SupplierItemService(ICommonRepository<SupplierItem> commonRepository, IMapper mapper)
        {
            this.commonRepository = commonRepository;
            this.mapper = mapper;
        }

        public async Task<IEnumerable<SupplierItem>> GetAllSupplierItemsAsync(int pageNumber, int pageSize)
        {
            var supplierItems = await commonRepository.GetAllAsync();
            return supplierItems;
        }

        public async Task<SupplierItem> GetSupplierItemByIdAsync(Guid id)
        {
            return await commonRepository.GetByIdAsync(id);
        }

        public async Task AddSupplierItemAsync(SupplierItemDto supplierItemDto)
        {
            foreach (var selectedItem in supplierItemDto.SelectedSupplierItems)
            {
                if (Guid.TryParse(selectedItem, out Guid itemId))
                {
                    var newSupplierItemDto = new SupplierItemDto
                    {
                        SupplierId = supplierItemDto.SupplierId,
                        ItemId = itemId
                    };

                    var supplierItem = mapper.Map<SupplierItem>(newSupplierItemDto);
                    commonRepository.Add(supplierItem);
                    await commonRepository.SaveChangesAsync();
                }
                else
                {

                }
            }
            
        }

        public async Task UpdateSupplierItemAsync(Guid id, SupplierItemDto supplierItemDto)
        {
            var existingSupplierItemIds = await GetIdBySupplierIdAsync(supplierItemDto.SupplierId);

            
            foreach (var existingItemId in existingSupplierItemIds)
            {
                await DeleteSupplierItemAsync(existingItemId);
            }

            
            foreach (var selectedItem in supplierItemDto.SelectedSupplierItems)
            {
                if (Guid.TryParse(selectedItem, out Guid itemId))
                {
                    var newSupplierItemDto = new SupplierItemDto
                    {
                        SupplierId = supplierItemDto.SupplierId,
                        ItemId = itemId
                    };

                    var supplierItem = mapper.Map<SupplierItem>(newSupplierItemDto);
                    commonRepository.Add(supplierItem);
                    await commonRepository.SaveChangesAsync();
                }
                else
                {
                    
                }
            }
        }

        public async Task<IEnumerable<Guid>> GetItemIdsBySupplierIdAsync(Guid supplierId)
        {
            var supplierItems = await commonRepository.GetAllAsync();
            var itemIds = supplierItems
                .Where(item => item.SupplierId == supplierId)
                .Select(item => item.ItemId)
                .ToList();
            return itemIds;
        }

        public async Task<IEnumerable<Guid>> GetIdBySupplierIdAsync(Guid supplierId)
        {
            var supplierItems = await commonRepository.GetAllAsync();
            var itemIds = supplierItems
                .Where(item => item.SupplierId == supplierId)
                .Select(item => item.Id)
                .ToList();
            return itemIds;
        }

        public async Task DeleteSupplierItemAsync(Guid id)
        {
            await commonRepository.Delete(id);
            await commonRepository.SaveChangesAsync();
        }
    }
}
