﻿using AutoMapper;
using Demo.Api.Data;
using Demo.Api.Interfaces;
using Demo.Api.Models;
using Demo.Api.Models.Dto;
using Microsoft.EntityFrameworkCore;

namespace Demo.Api.Services
{
    public class SupplierService : ISupplierRepository
    {
        private readonly ICommonRepository<Supplier> commonRepository;
        private readonly ISupplierItemRepository supplierItemRepository;

        private readonly ApplicationDbContext applicationDbContext;
        private IMapper mapper;

        public SupplierService(ApplicationDbContext applicationDbContext, ICommonRepository<Supplier> commonRepository, IMapper mapper, ISupplierItemRepository supplierItemRepository)
        {
            this.applicationDbContext = applicationDbContext;
            this.commonRepository = commonRepository;
            this.mapper = mapper;
            this.supplierItemRepository = supplierItemRepository;
        }

        public async Task<Supplier> GetSupplierByIdAsync(Guid id)
        {
            var supplier = await applicationDbContext.Suppliers
                .Include(s => s.SupplierItems.Where(si => si.DeletedOn == null))
                    .ThenInclude(si => si.Item) 
                .Include(s => s.City) // Include the related City
                .FirstOrDefaultAsync(s => s.Id == id && s.DeletedOn == null);

            return supplier;
        }

        public async Task<IEnumerable<Supplier>> GetAllSuppliersAsync()
        {
            var suppliers = await applicationDbContext.Suppliers
                .Include(s => s.SupplierItems)
                    .ThenInclude(si => si.Item)
                .Include(s => s.City)
                .Where(s => s.DeletedOn == null)
                .ToListAsync();

            return suppliers;
        }

        public async Task<Supplier> AddSupplierAsync(SupplierDto supplierDto)
        {
            var supplier = mapper.Map<Supplier>(supplierDto);
            commonRepository.Add(supplier);
            await commonRepository.SaveChangesAsync();

            var selectedItems = supplierDto.SelectedSupplierItems;
            var supplierItemDto = new SupplierItemDto
            {
                SupplierId = supplier.Id,
                SelectedSupplierItems = selectedItems
            };
            await supplierItemRepository.AddSupplierItemAsync( supplierItemDto);

            return supplier;
        }
        public async Task UpdateSupplierAsync(Guid id, SupplierDto supplierDto)
        {
            var existingSupplier = await commonRepository.GetByIdAsync(id);
            if (existingSupplier == null)
            {
                throw new Exception("Supplier not found.");
            }

            var supplier = mapper.Map<Supplier>(supplierDto);

            existingSupplier.Name = supplier.Name;
            existingSupplier.ItemPrice = supplier.ItemPrice;
            existingSupplier.Mobile = supplier.Mobile;
            existingSupplier.Address = supplier.Address;
            existingSupplier.CityId = supplier.CityId;
            existingSupplier.ZIPCode = supplier.ZIPCode;
            existingSupplier.Country = supplier.Country;

            commonRepository.Update(existingSupplier);
            await commonRepository.SaveChangesAsync();

            var selectedItems = supplierDto.SelectedSupplierItems;
            var supplierItemDto = new SupplierItemDto
            {
                SupplierId = existingSupplier.Id,
                SelectedSupplierItems = selectedItems
            };

            await supplierItemRepository.UpdateSupplierItemAsync(id, supplierItemDto);
        }
        public async Task DeleteSupplierAsync(Guid id)
        {
            await commonRepository.Delete(id);
            await commonRepository.SaveChangesAsync();
            return;
        }
    }
}
