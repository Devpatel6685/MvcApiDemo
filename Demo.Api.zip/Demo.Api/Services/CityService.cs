﻿using AutoMapper;
using Demo.Api.Interfaces;
using Demo.Api.Models;
using Demo.Api.Models.Dto;

namespace Demo.Api.Services
{
    public class CityService : ICityRepository
    {
        private readonly ICommonRepository<City> commonRepository;
        private IMapper Mapper;

        public CityService(ICommonRepository<City> commonRepository, IMapper mapper)
        {
            this.commonRepository = commonRepository;
            this.Mapper = mapper;
        }

        public async Task<IEnumerable<City>> GetAllCitiesAsync(int pageNumber, int pageSize)
        {
            var cities = await commonRepository.GetAllAsync();
            return cities;
        }

        public async Task<City> GetCityByIdAsync(Guid id)
        {
            return await commonRepository.GetByIdAsync(id);
        }

        public async Task AddCityAsync(CityDto cityDto)
        {
            var city = Mapper.Map<City>(cityDto);
            commonRepository.Add(city);
            await commonRepository.SaveChangesAsync();
        }

        public async Task UpdateCityAsync(Guid id, CityDto cityDto)
        {
            var existingCity = await commonRepository.GetByIdAsync(id);
            if (existingCity == null)
            {
                throw new Exception("City not found.");
            }
            var city = Mapper.Map<City>(cityDto);
            existingCity.Name= city.Name;
            existingCity.Description= city.Description;
            commonRepository.Update(existingCity);
            await commonRepository.SaveChangesAsync();
        }

        public async Task DeleteCityAsync(Guid id)
        {
            await commonRepository.Delete(id);
            await commonRepository.SaveChangesAsync();
        }
    }
}
