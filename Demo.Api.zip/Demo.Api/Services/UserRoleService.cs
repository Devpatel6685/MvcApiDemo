﻿using Demo.Api.Interfaces;
using Demo.Api.Models;

namespace Demo.Api.Services
{
    public class UserRoleService : IUserRoleRepository
    {
        private readonly ICommonRepository<UserRole> commonRepository;

        public UserRoleService(ICommonRepository<UserRole> commonRepository)
        {
            this.commonRepository = commonRepository;
        }

        public async Task<UserRole> GetUserRoleByIdAsync(Guid id)
        {
            return await commonRepository.GetByIdAsync(id);
        }

        public async Task AddUserRoleAsync(UserRole userRole)
        {
            commonRepository.Add(userRole);
            await commonRepository.SaveChangesAsync();
            return;
        }

        public async Task UpdateUserRoleAsync(Guid id, UserRole userRole)
        {
            var existingUserRole = await commonRepository.GetByIdAsync(id);
            if (existingUserRole == null)
            {
                throw new Exception("UserRole not found.");
            }
            if (userRole.UserId != Guid.Empty)
            {
                existingUserRole.UserId = userRole.UserId;
            }
            if (userRole.RoleId != Guid.Empty)
            {
                existingUserRole.RoleId = userRole.RoleId;
            }
            commonRepository.Update(existingUserRole);
            await commonRepository.SaveChangesAsync();
            return;
        }

        public async Task DeleteUserRoleAsync(Guid id)
        {
            await commonRepository.Delete(id);
            await commonRepository.SaveChangesAsync();
            return;
        }
    }
}
