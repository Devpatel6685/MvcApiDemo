﻿using AutoMapper;
using Demo.Api.Interfaces;
using Demo.Api.Models;
using Demo.Api.Models.Dto;

namespace Demo.Api.Services
{
    public class PageService : IPageRepository
    {
        private readonly ICommonRepository<Page> commonRepository;
        private IMapper mapper;

        public PageService(ICommonRepository<Page> commonRepository, IMapper mapper)
        {
            this.commonRepository = commonRepository;
            this.mapper = mapper;
        }

        public async Task<Page> GetPageByIdAsync(Guid id)
        {
            return await commonRepository.GetByIdAsync(id);
        }

        public async Task<IEnumerable<Page>> GetAllPagesAsync()
        {
            var pages = await commonRepository.GetAllAsync();
            return pages;
        }

        public async Task AddPageAsync(PageDto pageDto)
        {
            var page = mapper.Map<Page>(pageDto);
            commonRepository.Add(page);
            await commonRepository.SaveChangesAsync();
            return;
        }

        public async Task UpdatePageAsync(Guid id, PageDto pageDto)
        {
            var existingPage = await commonRepository.GetByIdAsync(id);
            if (existingPage == null)
            {
                throw new Exception("Page not found.");
            }

            var page = mapper.Map<Page>(pageDto);

            existingPage.Name = page.Name;

            commonRepository.Update(existingPage);
            await commonRepository.SaveChangesAsync();
            return;
        }

        public async Task DeletePageAsync(Guid id)
        {
            await commonRepository.Delete(id);
            await commonRepository.SaveChangesAsync();
            return;
        }
    }
}
