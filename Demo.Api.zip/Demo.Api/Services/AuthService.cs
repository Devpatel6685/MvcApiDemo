﻿using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Demo.Api.Data;
using Demo.Api.Interfaces;
using Demo.Api.Models.Dto;

namespace Demo.Api.Services
{
    public class AuthService : IAuthRepository
    {
        private readonly IConfiguration configuration;
        private byte[] secretKeyBytes;
        private readonly ApplicationDbContext applicationDbContext;
        private int tokenExpiry;

        public AuthService(ApplicationDbContext applicationDbContext, IConfiguration configuration)
        {
            this.applicationDbContext = applicationDbContext;
            this.configuration = configuration;
            string secretKey = this.configuration["JwtSettings:Key"];
            secretKeyBytes = Encoding.UTF8.GetBytes(secretKey);
            tokenExpiry = Convert.ToInt32(this.configuration["JwtSettings:TokenExpiry"]);
        }
        public AuthDto Login(LoginDto model)
        {
            var user = applicationDbContext.Users
                .Include(u => u.UserRoles)
                .FirstOrDefault(u => u.UserName == model.UserName && u.Password == model.Password);

            if (user != null)
            {
                var roleId = user.UserRoles.FirstOrDefault()?.RoleId;
                var roleName = applicationDbContext.Roles.Where(u => u.Id == roleId).FirstOrDefault()?.Name;

                var rolePagePermissions = applicationDbContext.RolePagePermissions
           .Where(rp => rp.RoleId == roleId && rp.DeletedOn == null)
           .Select(rp => new
           {
               rp.RoleId,
               PageName = rp.Page.Name,
               PermissionName = rp.Permission.Name
           })
           .ToList();

                var token = GenerateJwtToken(user.Email, roleName);

                var loginResult = new AuthDto
                {
                    Token = token,
                    RoleName = roleName,
                    UserId = user.Id.ToString(),
                    RoleId = roleId.ToString(),
                    RolePagePermissions = rolePagePermissions
                        .GroupBy(rp => rp.PageName)
                        .ToDictionary(group => group.Key,
                                      group => group.Select(rp => rp.PermissionName).ToList())
                };

                return loginResult;
            }

            return null;
        }
        private string GenerateJwtToken(string email, string role)
        {
            var tokenHandler = new JwtSecurityTokenHandler();

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[]
                {
                    new Claim(ClaimTypes.Email, email),
                    new Claim(ClaimTypes.Role, role)
                }),
                Expires = DateTime.UtcNow.AddMinutes(tokenExpiry),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(secretKeyBytes), SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            var tokenString = tokenHandler.WriteToken(token);

            return tokenString;
        }
    }
}

