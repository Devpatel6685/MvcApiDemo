﻿using AutoMapper;
using Demo.Api.Interfaces;
using Demo.Api.Models;
using Demo.Api.Models.Dto;

namespace Demo.Api.Services
{
    public class ItemService : IItemRepository
    {
        private readonly ICommonRepository<Item> commonRepository;
        private IMapper Mapper;

        public ItemService(ICommonRepository<Item> commonRepository, IMapper mapper)
        {
            this.commonRepository = commonRepository;
            this.Mapper = mapper;
        }

        public async Task<IEnumerable<Item>> GetAllItemsAsync(int pageNumber, int pageSize)
        {
            var items = await commonRepository.GetAllAsync();
            return items;
        }

        public async Task<Item> GetItemByIdAsync(Guid id)
        {
            return await commonRepository.GetByIdAsync(id);
        }

        public async Task AddItemAsync(ItemDto itemDto)
        {
            var item = Mapper.Map<Item>(itemDto);
            commonRepository.Add(item);
            await commonRepository.SaveChangesAsync();
        }

        public async Task UpdateItemAsync(Guid id, ItemDto itemDto)
        {
            var existingItem = await commonRepository.GetByIdAsync(id);
            if (existingItem == null)
            {
                throw new Exception("Item not found.");
            }

            Mapper.Map(itemDto, existingItem);

            commonRepository.Update(existingItem);
            await commonRepository.SaveChangesAsync();
        }

        public async Task DeleteItemAsync(Guid id)
        {
            await commonRepository.Delete(id);
            await commonRepository.SaveChangesAsync();
        }
    }
}
