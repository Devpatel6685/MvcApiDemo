﻿using AutoMapper;
using Demo.Api.Interfaces;
using Demo.Api.Models;
using Demo.Api.Models.Dto;

namespace Demo.Api.Services
{
    public class CustomerService : ICustomerRepository
    {
        private readonly ICommonRepository<Customer> commonRepository;
        private IMapper mapper;

        public CustomerService(ICommonRepository<Customer> commonRepository, IMapper mapper)
        {
            this.commonRepository = commonRepository;
            this.mapper = mapper;
        }

        public async Task<Customer> GetCustomerByIdAsync(Guid id)
        {
            return await commonRepository.GetByIdAsync(id);
        }

        public async Task AddCustomerAsync(CustomerDto customerDto)
        {
            var customer = mapper.Map<Customer>(customerDto);
            commonRepository.Add(customer);
            await commonRepository.SaveChangesAsync();
            return;
        }
        public async Task<IEnumerable<Customer>> GetAllCustomersAsync()
        {
            var customers = await commonRepository.GetAllAsync();
            return customers;
        }
        public async Task UpdateCustomerAsync(Guid id, CustomerDto customerDto)
        {
            var existingCustomer = await commonRepository.GetByIdAsync(id);
            if (existingCustomer == null)
            {
                throw new Exception("Customer not found.");
            }

            var customer = mapper.Map<Customer>(customerDto);

            existingCustomer.Name = customer.Name;
            existingCustomer.Mobile = customer.Mobile;
            existingCustomer.Address = customer.Address;
            existingCustomer.City = customer.City;
            existingCustomer.ZIPCode = customer.ZIPCode;
            existingCustomer.Country = customer.Country;

            commonRepository.Update(existingCustomer);
            await commonRepository.SaveChangesAsync();
            return;
        }

        public async Task DeleteCustomerAsync(Guid id)
        {
            await commonRepository.Delete(id);
            await commonRepository.SaveChangesAsync();
            return;
        }
    }
}
