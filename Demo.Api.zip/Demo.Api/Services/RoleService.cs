﻿using AutoMapper;
using Demo.Api.Data;
using Demo.Api.Interfaces;
using Demo.Api.Models;
using Demo.Api.Models.Dto;
using Microsoft.EntityFrameworkCore;
using System.Data;

namespace Demo.Api.Services
{
    public class RoleService : IRoleRepository
    {
        private readonly ICommonRepository<Role> commonRepository;
        private readonly ApplicationDbContext applicationDbContext;

        private IMapper mapper;

        public RoleService(ICommonRepository<Role> commonRepository, IMapper mapper, ApplicationDbContext applicationDbContext)
        {
            this.commonRepository = commonRepository;
            this.mapper = mapper;
            this.applicationDbContext = applicationDbContext;
        }

        public async Task<Role> GetRoleByIdAsync(Guid id)
        {
            var role = await applicationDbContext.Roles
                .FirstOrDefaultAsync(r => r.Id == id);

            return role;
        }

        public async Task AddRoleAsync(RoleDto roleDto)
        {
            var role = mapper.Map<Role>(roleDto);
            commonRepository.Add(role);
            await commonRepository.SaveChangesAsync();
            return;
        }

        public async Task<IEnumerable<Role>> GetAllRolesAsync()
        {
            var roles = await commonRepository.GetAllAsync();
            return roles;
        }

        public async Task UpdateRoleAsync(Guid id, RoleDto roleDto)
        {
            var existingRole = await commonRepository.GetByIdAsync(id);
            if (existingRole == null)
            {
                throw new Exception("Role not found.");
            }

            var role = mapper.Map<Role>(roleDto);

            existingRole.Name = role.Name;

            commonRepository.Update(existingRole);
            await commonRepository.SaveChangesAsync();
            return;
        }

        public async Task DeleteRoleAsync(Guid id)
        {
            await commonRepository.Delete(id);
            await commonRepository.SaveChangesAsync();
            return;
        }
    }
}
