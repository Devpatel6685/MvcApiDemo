﻿using Demo.Api.Interfaces;

namespace Demo.Api.Services
{
    public static class ServiceCollectionExtension
    {
        public static IServiceCollection RegisterServices(this IServiceCollection services) { 
            services.AddScoped<IAuthRepository, AuthService>();
            services.AddScoped(typeof(ICommonRepository<>), typeof(CommonService<>));
            services.AddScoped(typeof(IUserRepository), typeof(UserService));
            services.AddScoped(typeof(IUserRoleRepository), typeof(UserRoleService));
            services.AddScoped(typeof(ICustomerRepository), typeof(CustomerService));
            services.AddScoped(typeof(ISupplierRepository), typeof(SupplierService));
            services.AddScoped(typeof(IRoleRepository), typeof(RoleService));
            services.AddScoped(typeof(IPageRepository), typeof(PageService));
            services.AddScoped(typeof(IItemRepository), typeof(ItemService));
            services.AddScoped(typeof(ICityRepository), typeof(CityService));
            services.AddScoped(typeof(ISupplierItemRepository), typeof(SupplierItemService));
            services.AddScoped(typeof(IRolePagePermissionRepository), typeof(RolePagePermissionService));
            services.AddScoped(typeof(IPermissionRepository), typeof(PermissionService));



            return services;
        }
    }
}
