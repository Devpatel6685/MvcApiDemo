﻿using AutoMapper;
using Demo.Api.Interfaces;
using Demo.Api.Models;
using Demo.Api.Models.Dto;

namespace Demo.Api.Services
{
    public class UserService : IUserRepository
    {
        private readonly ICommonRepository<User> commonRepository;
        private readonly IUserRoleRepository userRoleRepository;
        private IMapper Mapper;

        public UserService(ICommonRepository<User> commonRepository, IMapper mapper, IUserRoleRepository userRoleRepository)
        {
            this.commonRepository = commonRepository;
            this.Mapper = mapper;
            this.userRoleRepository = userRoleRepository;
        }

        public async Task<IEnumerable<User>> GetAllUsersAsync()
        {
            var users = await commonRepository.GetAllAsync();
            return users;
        }

        public async Task<User> GetUserByIdAsync(Guid id)
        {
            return await commonRepository.GetByIdAsync(id);
        }

        public async Task AddUserAsync(UserDto userdto)
        {
            var user = Mapper.Map<User>(userdto);
            commonRepository.Add(user);
            await commonRepository.SaveChangesAsync();    
            var userRole = new UserRole
            {
                UserId = user.Id,
                RoleId = Guid.Parse(userdto.RoleId), 
            };

            // Add the user role
            await userRoleRepository.AddUserRoleAsync(userRole);
            return;
        }
        public async Task UpdateUserAsync(Guid id, UserDto userdto)
        {
            var existingUser = await commonRepository.GetByIdAsync(id);
            if (existingUser == null)
            {
                throw new Exception("User not found.");
            }

            var user = Mapper.Map<User>(userdto);

            existingUser.Name = user.Name;
            existingUser.Mobile = user.Mobile;
            existingUser.Address = user.Address;
            existingUser.Email = user.Email;
            existingUser.UserName = user.UserName;
            existingUser.Password = user.Password;

            commonRepository.Update(existingUser);
            await commonRepository.SaveChangesAsync();
            return;
        }

        public async Task DeleteUserAsync(Guid id)
        {
            await commonRepository.Delete(id);
            await commonRepository.SaveChangesAsync();
            return;
        }
    }
}
