﻿using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;
using Demo.Api.Data;
using Demo.Api.Interfaces;
using Demo.Api.Models.Common;

namespace Demo.Api.Services
{
    public class CommonService<T> : ICommonRepository<T> where T : DbEntity
    {
        private readonly ApplicationDbContext context;
        private readonly DbSet<T> entities;

        public CommonService(ApplicationDbContext context)
        {
            this.context = context ?? throw new ArgumentNullException(nameof(context));
            this.entities = context.Set<T>();
        }

        public async Task<IEnumerable<T>> GetAllAsync()
        {
            return await entities.Where(e => e.DeletedOn == null).ToListAsync();
        }

        public async Task<T> GetByIdAsync(Guid id)
        {
            return await entities.FindAsync(id);
        }

        public async Task<T> FindByConditionAsync(Expression<Func<T, bool>> predicate)
        {
            return await entities.Where(e => e.DeletedOn == null).FirstOrDefaultAsync(predicate);
        }

        public void Add(T entity)
        {
            entity.CreatedOn = DateTime.Now;
            entity.UpdatedOn = DateTime.Now;
            entities.Add(entity);
        }

        public void Update(T entity)
        {
            entity.UpdatedOn = DateTime.Now;
            entities.Update(entity);
        }

        public async Task Delete(Guid id)
        {
            var entity = await entities.FindAsync(id);
            if (entity != null)
            {
                if (typeof(T).GetProperty("DeletedOn") != null)
                {
                    entity.DeletedOn = DateTime.Now;
                    entities.Update(entity);
                }
                else
                {
                    entities.Remove(entity);
                }
            }
        }

        public async Task<bool> SaveChangesAsync()
        {
            return await context.SaveChangesAsync() > 0;
        }
    }
}
